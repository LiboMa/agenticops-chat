(()=>{
const B=(zh,en)=>({zh,en}),D={
 prototype:B('界面优化范本 · 核心页面为本地演示 · ↗ 打开现有产品','UI refinement prototype · Core pages use local demos · ↗ opens the existing product'),
 oldA:B('查看原 A 版','Original design A'),review:B('查看改进与保留范围','Changes and retained scope'),
 workspace:B('工作区','Workspace'),capabilities:B('能力与治理','Capabilities'),dashboard:B('总览','Dashboard'),chat:B('Chat 对话','Chat'),
 issues:B('事件','Issues'),plans:B('方案与变更','Plans & changes'),resources:B('资源','Resources'),reports:B('报告','Reports'),
 schedules:B('定时任务','Schedules'),metrics:B('Agent 指标','Agent metrics'),skills:B('技能','Skills'),galaxy:B('Galaxy','Galaxy'),security:B('安全','Security'),settings:B('设置','Settings'),
 existing:B('打开现有产品页面','Open the existing product page'),readonly:B('示例工作区 / UTC+08:00','Sample workspace / UTC+08:00'),
 allScopes:B('全部示例账户','All sample accounts'),globalSearch:B('搜索事件、方案、资源','Search issues, plans, resources'),
 search:B('搜索编号、名称或资源','Search ID, name or resource'),all:B('全部','All'),needsEvidence:B('待补证','Needs evidence'),ready:B('待审阅','Ready for review'),
 rows:B('条示例记录','sample records'),showing:B('已显示','Showing'),noResults:B('没有符合条件的记录','No matching records'),
 clearFilters:B('清除筛选','Clear filters'),emptySelect:B('请选择列表中的记录','Select a record from the list'),emptySelectHint:B('调整筛选条件或选择一条记录以查看详情。','Adjust the filters or select a record to view its details.'),
 askAgent:B('询问 Agent','Ask Agent'),viewPlan:B('查看修复方案','View fix plan'),more:B('更多操作','More actions'),notes:B('补充说明','Add context'),
 created:B('发现时间','Detected'),updated:B('更新时间','Updated'),owner:B('负责人','Owner'),oncall:B('值班工程师','On-call engineer'),
 issueState:B('事件','Issue'),rcaState:B('RCA','RCA'),planState:B('方案','Plan'),runState:B('执行','Execution'),
 investigating:B('调查中','Investigating'),inProgress:B('处理中','In progress'),complete:B('已完成','Completed'),notStarted:B('未开始','Not started'),notExecuted:B('尚未执行','Not executed'),
 noPlan:B('尚无方案','No plan yet'),approved:B('已批准','Approved'),rejected:B('已驳回','Rejected'),pendingApproval:B('待审批','Awaiting approval'),
 manualResolved:B('人工标记已解决','Manually marked resolved'),dismissed:B('已关闭','Dismissed'),
 workflow:B('处理流程','Response workflow'),expandProcess:B('展开完整流程','Expand workflow'),stepEvent:B('事件产生','Detected'),stepInvestigate:B('调查','Investigate'),stepRca:B('RCA','RCA'),stepPlan:B('方案','Plan'),stepReview:B('审批','Approve'),stepRun:B('执行','Execute'),stepVerify:B('验证','Verify'),
 overview:B('概览','Overview'),rca:B('RCA 详情','RCA detail'),evidence:B('证据','Evidence'),timeline:B('处理记录','Activity'),relatedPlans:B('关联方案','Plans'),relatedResources:B('关联资源','Resources'),report:B('报告','Report'),
 conclusion:B('调查结论','Finding'),impact:B('业务影响','Business impact'),unknown:B('尚待确认','Open questions'),next:B('建议下一步','Recommended next step'),
 relatedFix:B('关联修复方案','Related fix plan'),allEvidence:B('查看全部证据','View all evidence'),reviewPlan:B('审阅方案','Review plan'),
 target:B('目标','Target'),sourceIssue:B('来源事件','Originating issue'),version:B('版本','Version'),verification:B('恢复验证','Recovery verification'),unverified:B('尚未验证','Not verified'),evidenceCoverage:B('证据记录','Evidence records'),pending:B('未运行','Not run'),
 noPlanHint:B('当前根因证据不足。保留调查过程，补齐证据后再准备修复方案。','Root-cause evidence is insufficient. Keep the investigation and collect evidence before preparing a fix plan.'),
 noReport:B('此事件尚无报告','No report for this issue'),noReportHint:B('报告属于具体事件；此处不会替换成其他事件的报告。','Reports belong to a specific issue. Another issue’s report is not substituted here.'),
 explain:B('解释与依据','Explanation and evidence'),diagnosticQuality:B('诊断质量与反馈','Diagnostic quality and feedback'),confidence:B('模型自评','Model self-assessment'),notProbability:B('不是经校准的根因概率','Not a calibrated root-cause probability'),
 critic:B('复核意见','Review notes'),criticText:B('调查结论有来源支持；恢复验证仍缺失。','The finding has traceable support; recovery verification is still missing.'),criticMissing:B('缺少慢查询与锁等待证据，尚不能确认根因。','Slow-query and lock-wait evidence are missing; the root cause is not confirmed.'),
 correct:B('标记诊断正确','Mark diagnosis correct'),incorrect:B('请求修正诊断','Request diagnosis correction'),
 source:B('来源','Source'),traceable:B('来源可追溯','Traceable source'),missing:B('缺少数据','Missing data'),rawEvidence:B('原始证据','Original evidence'),
 noteLabel:B('补充调查背景','Additional investigation context'),notePlaceholder:B('记录发现、业务背景或需要 Agent 进一步核对的信息…','Record findings, business context or questions for the Agent…'),
 saveNote:B('保存说明','Save note'),localOnly:B('仅保存于当前原型页面，刷新后重置','Saved in this prototype page only; reset on refresh'),
 received:B('接收到异常事件','Issue received'),collected:B('已采集诊断证据','Evidence collected'),rcaPrepared:B('已形成调查结论','Finding prepared'),planPrepared:B('修复方案已准备','Fix plan prepared'),
 fixPlans:B('修复方案','Fix plans'),changePlans:B('变更计划','Change plans'),audit:B('审计记录','Audit'),
 plansIntro:B('审阅修复与变更方案，跟踪审批和执行记录。','Review remediation and change plans, and track their approval and execution records.'),
 risk:B('风险','Risk'),allRisks:B('全部风险','All risk levels'),allStatuses:B('全部状态','All statuses'),approval:B('审批记录','Approval'),execution:B('执行记录','Execution'),commands:B('命令与参数','Commands & parameters'),
 why:B('为什么这样改','Why this change'),what:B('具体改什么','What will change'),riskScope:B('风险与范围','Risk and scope'),rollback:B('何时回滚','When to roll back'),
 check:B('检查项','Check'),passCondition:B('通过条件','Pass condition'),result:B('结果','Result'),approve:B('批准','Approve'),reject:B('驳回','Reject'),execute:B('执行','Execute'),
 versionBound:B('审批绑定当前版本和目标范围。方案内容变更后，应重新审阅。','Approval binds to this version and target scope. Changed plan content requires another review.'),
 noApproval:B('尚无审批记录','No approval recorded'),noApprovalHint:B('审阅目标、改动、风险、验证与回滚后，再决定是否批准。','Review the target, change, risk, verification and rollback before approving.'),
 noExecution:B('尚无执行结果','No execution result'),noExecutionHint:B('当前方案尚未执行。验证项保留“未运行”，不会因生成或批准方案而变为通过。','This plan has not run. Checks remain “Not run”; preparing or approving a plan does not make them pass.'),
 requestRecorded:B('已记录演示执行请求','Demo execution request recorded'),requestRecordedHint:B('这里只演示请求与记录，没有调用任何云端工具。','This demonstrates the request and record only. No cloud tools were called.'),
 rejectionReason:B('驳回原因','Rejection reason'),changePurpose:B('主动变更','Proactive change'),requestedBy:B('申请人','Requested by'),request:B('用户请求','User request'),window:B('变更窗口','Change window'),
 changeTitle:B('订单数据库备份保留期调整','Adjust order-database backup retention'),
 changeWhy:B('将备份保留期从 7 天调整为 14 天，以满足业务恢复窗口要求。','Change backup retention from 7 to 14 days to meet the required recovery window.'),
 changeRisk:B('仅调整 orders-db 的备份保留设置，预期增加备份存储占用；不改变实例规格与网络设置。','Only orders-db backup retention changes. Backup storage use may increase; instance size and network settings remain unchanged.'),
 changeRollback:B('如果备份或数据库可用性出现异常，恢复到 7 天，并核对备份任务状态。','If backup or database availability becomes abnormal, restore 7 days and inspect backup-job status.'),
 changeStep1:B('核对数据库身份、现有保留期和最近备份。','Verify database identity, current retention and the latest backup.'),changeStep2:B('在批准的窗口内将保留期调整为 14 天。','Set retention to 14 days during the approved window.'),changeStep3:B('检查配置生效、备份状态和数据库可用性。','Verify the setting, backup status and database availability.'),
 changeCheck1:B('备份保留期显示为 14 天','Backup retention is 14 days'),changeCheck2:B('数据库可用，备份任务无异常','Database is available and backup jobs show no abnormality'),
 action:B('操作','Action'),actor:B('操作者','Actor'),object:B('对象','Object'),time:B('时间','Time'),noAudit:B('暂无演示操作记录','No demo actions recorded'),
 reviewIntro:B('本页只演示界面交互。确认后记录本地示例，不会修改真实产品或环境。','This page demonstrates the interface only. Confirmation records a local example without changing the real product or environment.'),
 reason:B('说明','Reason'),confirmVersion:B('我已核对当前版本、目标范围、风险及恢复验证条件。','I have reviewed this version, target scope, risks and recovery checks.'),
 recordDemo:B('记录演示操作','Record demo action'),cancel:B('取消','Cancel'),close:B('关闭','Close'),required:B('请填写说明并核对当前方案。','Provide a reason and review the current plan.'),checkRequired:B('请先勾选当前版本与范围的核对项。','Confirm the version and scope review first.'),reasonRequired:B('请填写说明。','Provide a reason.'),
 saved:B('演示记录已保存，真实产品未被修改。','Demo record saved. The real product was not changed.'),noteSaved:B('说明已保存在当前原型中。','Note saved in this prototype.'),rejectNoReason:B('驳回需要填写原因。','A reason is required to reject.'),
 resolve:B('标记为已解决','Mark as resolved'),falsePositive:B('标记为误报','Mark as false positive'),dismiss:B('关闭事件','Dismiss issue'),feedback:B('诊断反馈','Diagnostic feedback'),
 resourceIntro:B('查看云资源健康、最新观测及关联事件。','Inspect resource health, recent observations and related issues.'),
 resourceSearch:B('搜索名称、ID、类型或区域','Search name, ID, type or region'),name:B('名称','Name'),type:B('类型','Type'),account:B('账户','Account'),region:B('区域','Region'),health:B('健康','Health'),lifecycle:B('运行状态','Lifecycle'),observed:B('最近观测','Last observed'),
 columns:B('显示列','Columns'),allTypes:B('全部类型','All types'),backResources:B('返回资源列表','Back to resources'),identity:B('资源身份','Resource identity'),nativeId:B('云资源 ID','Cloud resource ID'),service:B('服务','Service'),
 relatedIssues:B('关联事件','Issues'),network:B('网络与依赖','Network & dependencies'),tags:B('标签','Tags'),raw:B('原始属性','Raw attributes'),noIssues:B('暂无关联事件','No linked issues'),noIssuesHint:B('当前示例没有关联事件，不代表已证明不存在风险。','No issue is linked in this sample. This does not prove an absence of risk.'),
 dependencyHint:B('连线表达依赖关系，不直接证明故障因果。','Edges represent dependencies; they do not prove fault causation.'),noDependencies:B('当前示例没有记录更多依赖。','No further dependencies are recorded in this sample.'),
 reportsIntro:B('按版本查看调查报告，选择阅读与交付语言。','Read versioned investigation reports and choose the delivery language.'),
 currentLanguage:B('当前语言','Current language'),bilingual:B('中英对照','Chinese / English'),export:B('导出 HTML','Export HTML'),print:B('打印','Print'),publish:B('发布','Publish'),share:B('分享','Share'),
 interim:B('阶段性报告','Interim report'),observedWindow:B('观测区间','Observation window'),generated:B('生成时间','Generated'),actions:B('建议行动','Recommended actions'),evidenceIndex:B('证据索引','Evidence index'),limitations:B('未确认事项','Open questions'),
 reportNote:B('报告与方案版本、证据引用保持绑定。语言切换不改变事实或状态。','The report stays bound to its plan version and evidence. Language switching does not change facts or states.'),
 reportExported:B('已导出当前语言设置下的完整报告。','The complete report was exported using the current language setting.'),
 shareHint:B('下方为本地审阅链接。正式产品的分享权限和渠道保持原有机制。','This is a local review link. The product’s sharing permissions and channels retain their existing mechanism.'),
 conversation:B('对话','Conversation'),conversationHint:B('围绕当前事件追问、补充证据和协作。','Ask follow-up questions, add evidence and collaborate on this issue.'),
 session:B('会话','Session'),newContext:B('事件调查','Issue investigation'),agent:B('SRE Agent','SRE Agent'),sampleReply:B('示例回复','Sample reply'),you:B('你','You'),
 seedQuestion:B('请解释这个事件的调查结论。','Explain the finding for this issue.'),chatInput:B('输入问题、补充背景或要求修订方案…','Ask a question, add context or request a plan revision…'),
 attachments:B('附件','Attachments'),send:B('发送','Send'),chatLocal:B('本地示例回复；附件仅预览，不上传或分析。','Local sample replies; files are previewed only, not uploaded or analysed.'),
 chatReply:B('这是当前事件的演示回复。实际接入时，问题会携带当前事件、资源和方案版本一起交给 Agent。','This is a demo response for the current issue. In the product, the question would be sent to the Agent with this issue, resource and plan version.'),
 fileReply:B('附件已保留在当前对话中用于本地预览。本范本没有上传或分析附件内容。','The attachment stays in this conversation for local preview. This prototype has not uploaded or analysed its contents.'),
 attachmentOnly:B('补充这些材料。','Add these materials.'),removeAttachment:B('移除附件','Remove attachment'),tooLarge:B('示例附件请限制在 20 MB 以内。','Keep sample attachments within 20 MB.'),
 linkedContext:B('关联上下文','Linked context'),openChatPage:B('打开完整 Chat','Open full Chat'),backIssue:B('返回事件','Back to issue'),
 retained:B('功能与入口保留清单','Retained functions and entries'),designTitle:B('沿用 A 的视觉风格，保留现有工作方式','Keep A’s visual style and the existing workflow'),
 designIntro:B('这份范本主要优化阅读顺序、控件位置和页面一致性。核心页面使用示例数据；其他模块保留到现有产品的入口。','This prototype refines reading order, control placement and consistency. Core pages use sample data; other modules retain links to the existing product.'),
 preserved:B('保留','Retained'),improved:B('界面调整','UI refinement'),demoBoundary:B('范本边界','Prototype scope'),demoBoundaryText:B('这里不是后端功能的复制实现。审批、执行、发布等仅演示确认与记录；原始 API、权限、云操作均未改动。','This is not a duplicate implementation of the backend. Approval, execution and publishing demonstrate confirmation and records only. Existing APIs, permissions and cloud operations are unchanged.'),
 resourceCount:B('资源记录','Resource records'),clear:B('清除','Clear'),navigation:B('导航','Navigation')
};
Object.assign(D,{
 issues:B('事件','Cases'),dashboard:B('运行总览','Runtime overview'),chat:B('对话','Chat'),
 dailyWork:B('日常工作','Daily work'),tools:B('运维工具','Operations tools'),admin:B('管理','Administration'),
 newChat:B('新建对话','New chat'),recentChats:B('最近对话','Recent conversations'),untitledChat:B('新需求','New request'),
 requestTitle:B('这次需要处理什么？','What would you like to work on?'),
 requestHint:B('描述目标，选择环境。需要时附上日志、截图或文件。','Describe your goal and choose an environment. Add logs, screenshots or files when helpful.'),
 requestInput:B('例如：检查订单服务，分析过去一小时的错误并给出建议…','For example: inspect the order service, analyse errors from the last hour and recommend next steps…'),
 requestScope:B('环境范围','Environment scope'),unlinkedChat:B('独立需求','Independent request'),
 requestReply:B('已记录你的需求。下一步需要确认目标资源、时间范围和期望结果；涉及变更时，再明确验证与回滚条件。这里仅展示交互，没有发起检查、创建事件或执行变更。','Your request is captured. The next step is to confirm the target resources, time range and expected outcome, then verification and rollback conditions for any change. This is an interface demo; no checks, cases or changes have been started.'),
 promptInvestigate:B('排查一个问题','Investigate a problem'),promptChange:B('准备一次变更','Prepare a change'),promptReport:B('整理一份报告','Prepare a report'),
 promptInvestigateText:B('请帮我排查一个问题。现象是：\n涉及的服务或资源：\n发生时间：','Help me investigate a problem.\nObserved symptoms:\nAffected service or resources:\nTime range:'),
 promptChangeText:B('请帮我准备一份变更方案。\n目标资源：\n希望完成的改动：\n可用的变更窗口：','Help me prepare a change plan.\nTarget resources:\nDesired change:\nAvailable change window:'),
 promptReportText:B('请帮我整理一份报告。\n相关事件或服务：\n报告时间范围：\n读者和关注点：','Help me prepare a report.\nRelated cases or service:\nReporting period:\nAudience and focus:'),
 scopeBound:B('范围已绑定此对话','Scope is bound to this conversation'),
 draft:B('草稿','Draft'),backIssue:B('查看事件','View case'),
 designTitle:B('从需求开始：对话、事件、报告','Start with the task: Chat, Cases, Reports'),
 designIntro:B('日常入口按用户要做的事组织。默认进入对话，直接提出需求；事件和报告独立阅读。运维工具与管理能力仍可展开访问。','Organise daily navigation around the task. Start in Chat to make a request; read Cases and Reports independently. Operations tools and administration remain accessible in expandable groups.')
});
Object.assign(D,{
 prototype:B('蓝白版审阅范本 · 示例数据 · 尚未接入 API','Blue/white review prototype · Sample data · API integration pending'),
 preferences:B('首页与语言','Home & language'),homeChoice:B('默认入口','Default entry'),resume:B('继续上次工作','Resume last workspace'),
 attention:B('需要你处理','Needs your attention'),savePreferences:B('保存偏好','Save preferences'),preferencesSaved:B('首页偏好已保存到此浏览器。','Home preference saved in this browser.'),
 preferencesHint:B('首次进入对话，之后按此设置打开。通知链接仍直达对应事件、方案或报告。','Start in Chat on first visit, then use this setting. Notification links still open their specific case, plan or report.'),
 preferencesLocal:B('偏好保存在当前浏览器；演示消息和附件在刷新后重置。','Preferences stay in this browser; demo messages and attachments reset on refresh.'),
 materialLimits:B('最多 5 个附件；按现有文件类型限制大小。','Up to 5 attachments; size limits follow existing file types.'),tooMany:B('每次最多附加 5 个文件。','Attach up to 5 files per message.'),tooLarge:B('文件超出当前类型的大小限制。','File exceeds the limit for its type.')
});
const preferenceKey='agenticops-bluewhite-prototype-v1';
let savedPreferences={};try{savedPreferences=JSON.parse(localStorage.getItem(preferenceKey)||'{}')}catch{}
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const Q=new URLSearchParams(location.search),valid=['issues','plans','resources','chat','reports','review'];
if(!Q.has('page')){
 const preferred=['chat','issues','reports'].includes(savedPreferences.home)?savedPreferences.home:null;
 if(preferred)Q.set('page',preferred);
 else if(valid.includes(savedPreferences.last?.page))for(const [k,v] of Object.entries(savedPreferences.last))if(['page','issue','resource','chat','itab','ptab','rtab','kind','view','scope'].includes(k)&&typeof v==='string')Q.set(k,v);
}
if(!Q.has('lang')&&['zh','en'].includes(savedPreferences.lang))Q.set('lang',savedPreferences.lang);
const S={lang:Q.get('lang')==='en'?'en':'zh',page:valid.includes(Q.get('page'))?Q.get('page'):'chat',issue:ISSUES.some(x=>x.id===Q.get('issue'))?Q.get('issue'):'I-2401',resource:RESOURCES.some(x=>x.id===Q.get('resource'))?Q.get('resource'):'web',itab:Q.get('itab')||'overview',ptab:Q.get('ptab')||'overview',rtab:Q.get('rtab')||'overview',kind:['fix','change','audit'].includes(Q.get('kind'))?Q.get('kind'):'fix',rview:Q.get('view')==='detail'?'detail':'list',scope:['all','prod-sg','prod-hk'].includes(Q.get('scope'))?Q.get('scope'):'all',filter:'all',query:'',planQuery:'',resourceQuery:'',resourceType:'all',risk:'all',reportMode:'current',open:{},notes:{},life:{},approvals:{},runRequests:{},audit:[],messages:{},drafts:{},files:{},columns:{type:true,account:true,region:true,health:true,observed:true},modal:null,reason:'',checked:false,error:'',search:'',nextFile:1,chatId:'request-1',sessions:[],nextChat:2,navOpen:{tools:['plans','resources'].includes(Q.get('page')),admin:false}};
S.sessions=[{id:'request-1',issue:null,title:null,scope:S.scope},...ISSUES.map(i=>({id:i.id,issue:i.id,title:null,scope:RESOURCES.find(r=>r.id===i.resource).account}))];
const requestedChat=Q.get('chat')||((Q.get('page')==='chat'&&Q.has('issue'))?Q.get('issue'):null);
if(S.sessions.some(c=>c.id===requestedChat))S.chatId=requestedChat;
S.home=['resume','chat','issues','reports'].includes(savedPreferences.home)?savedPreferences.home:'resume';
window.refinementState=S;
const tr=(v,lang=S.lang)=>v&&typeof v==='object'?v[lang]:String(v??'');
const t=(key,lang=S.lang)=>{if(!(key in D)&&!(key in UI))throw Error('Missing refinement translation: '+key);return tr(D[key]||UI[key],lang)};
const say=(zh,en)=>S.lang==='zh'?zh:en;
const fmt=(date,lang=S.lang)=>new Intl.DateTimeFormat(lang==='zh'?'zh-CN':'en-GB',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false,timeZone:'Asia/Shanghai'}).format(new Date(date));
const issue=()=>ISSUES.find(x=>x.id===S.issue),res=(id=S.resource)=>RESOURCES.find(x=>x.id===id),fix=()=>PLANS.find(p=>p.issue===S.issue);
const change={id:'C-041',version:2,resource:'db',title:D.changeTitle,why:D.changeWhy,risk:D.changeRisk,rollback:D.changeRollback,steps:[D.changeStep1,D.changeStep2,D.changeStep3],checks:[['V-21',D.changeCheck1],['V-22',D.changeCheck2]],commands:'BackupRetentionPeriod: 7 → 14\nDBInstanceIdentifier: db-demo-orders',kind:'change'};
const selectedPlan=()=>S.kind==='change'?change:fix();
const planStatus=p=>S.approvals[p.id]?.status||'pendingApproval';
const planRisk=p=>p.id==='P-126'?'L2':'L1';
const scopeMatches=r=>S.scope==='all'||r.account===S.scope;
const paths={brand:'M3 16l5-8 4 6 4-10 5 12M3 20h18',issues:'M6 3h12v18H6zM9 7h6M9 11h6M9 15h4',plans:'M8 3h8v4H8zM6 5H4v16h16V5h-2M8 12l2 2 5-5M8 18h8',resources:'M3 4h18v6H3zM3 14h18v6H3zM6 7h.01M6 17h.01',reports:'M6 3h9l4 4v14H6zM14 3v5h5M9 12h7M9 16h7',search:'M20 20l-5-5M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0',chat:'M4 4h16v12H9l-5 4z',dashboard:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',schedules:'M4 5h16v16H4zM8 3v4M16 3v4M4 10h16',metrics:'M4 20V10M10 20V4M16 20v-8M22 20H2',skills:'M3 8h6V3h6v5h6v7h-6v6H9v-6H3z',galaxy:'M12 3a9 9 0 1 0 9 9M3 12h18M12 3c5 4 5 14 0 18-5-4-5-14 0-18',security:'M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 12l3 3 5-6',settings:'M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8M12 2v4M12 18v4M2 12h4M18 12h4M5 5l3 3M16 16l3 3M5 19l3-3M16 8l3-3',more:'M5 12h.01M12 12h.01M19 12h.01',attach:'M8 12l6-6a3 3 0 014 4l-8 8a5 5 0 01-7-7l9-9',arrow:'M14 5l-7 7 7 7'};
const icon=n=>`<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[n]||paths.issues}"/></svg>`;
const btn=(key,a,attrs='',cls='')=>`<button class="btn ${cls}" data-a="${a}" ${attrs}>${t(key)}</button>`;
const badge=(key,cls='')=>`<span class="tag ${cls}">${t(key)}</span>`;
const navGroups=[
 {id:'dailyWork',entries:[['chat',null],['issues',null],['reports',null]]},
 {id:'tools',entries:[['plans',null],['resources',null],['schedules','/app/schedules']]},
 {id:'admin',entries:[['dashboard','/app'],['metrics','/app/agent-metrics'],['skills','/app/skills'],['galaxy','/app/galaxy'],['security','/app/security'],['settings','/app/settings']]}
];
const navEntries=navGroups.flatMap(g=>g.entries);
function navItem(key,path){return path?`<a class="nav-item" href="http://127.0.0.1:8000${path}" target="_blank" rel="noopener" title="${t('existing')}">${icon(key)}<span>${t(key)}</span><span class="external">↗</span></a>`:`<button class="nav-item ${S.page===key?'active':''}" data-a="nav" data-page="${key}" ${S.page===key?'aria-current="page"':''}>${icon(key)}<span>${t(key)}</span>${key==='issues'?'<span class="count">3</span>':''}</button>`}
function frame(){
 const chat=S.page==='chat'?activeChat():null,ci=chat?.issue?ISSUES.find(i=>i.id===chat.issue):null;
 const scopeLocked=(S.page==='resources'&&S.rview==='detail')||S.page==='reports'||!!(chat&&(ci||S.messages[chat.id]?.length));
 const displayScope=chat?(ci?res(ci.resource).account:chat.scope):S.page==='reports'?res('web').account:S.page==='resources'&&S.rview==='detail'?res().account:S.scope;
 return `<div class="review-strip"><span>${t('prototype')}</span><div class="review-links"><a href="implementation-review.html?lang=${S.lang}">${say('设计、API 与实施计划','Design, API & implementation plan')}</a><button data-a="nav" data-page="review">${t('review')}</button></div></div>
 <aside class="nav"><button class="brand" data-a="nav" data-page="chat" aria-label="AgenticOps · ${t('chat')}">${icon('brand')}AgenticOps</button><div class="nav-scroll"><div class="nav-label">${t('dailyWork')}</div><nav class="nav-primary" aria-label="${t('dailyWork')}">${navGroups[0].entries.map(x=>navItem(...x)).join('')}</nav>${navGroups.slice(1).map(g=>`<details class="nav-section" data-nav-group="${g.id}" ${S.navOpen[g.id]?'open':''}><summary>${t(g.id)}</summary><div>${g.entries.map(x=>navItem(...x)).join('')}</div></details>`).join('')}</div><div class="nav-bottom"><button class="nav-preferences" data-a="preferences">${t('preferences')}</button><div class="mode">${t('readonly')}</div></div></aside>
 <div class="shell"><header class="topbar"><div class="breadcrumb"><span>Acme</span><span>/</span><b>${t(S.page)}</b></div><select class="mobile-nav" id="mobile-nav" aria-label="${t('navigation')}">${navGroups.map(g=>`<optgroup label="${t(g.id)}">${g.entries.map(([k,p])=>`<option value="${k}" ${S.page===k?'selected':''}>${t(k)}${p?' ↗':''}</option>`).join('')}</optgroup>`).join('')}</select><div class="top-tools"><button class="attention-button" data-a="attention" aria-label="${t('attention')}"><span>${t('attention')}</span><b>${attentionItems().length}</b></button><button class="global-search" data-a="search" aria-label="${t('globalSearch')}">${icon('search')}<span>${t('globalSearch')}</span><kbd>⌘K</kbd></button><select id="global-scope" class="scope-select" aria-label="${t('requestScope')}" ${scopeLocked?'disabled':''}><option value="all" ${displayScope==='all'?'selected':''}>${t('allScopes')}</option><option value="prod-sg" ${displayScope==='prod-sg'?'selected':''}>prod-sg</option><option value="prod-hk" ${displayScope==='prod-hk'?'selected':''}>prod-hk</option></select><div class="lang" role="group" aria-label="Language / 语言"><button data-a="lang" data-lang="zh" class="${S.lang==='zh'?'active':''}" aria-pressed="${S.lang==='zh'}">中文</button><button data-a="lang" data-lang="en" class="${S.lang==='en'?'active':''}" aria-pressed="${S.lang==='en'}">English</button></div><span class="user-avatar">SRE</span></div></header><main class="main">${S.page==='issues'?issuesView():S.page==='plans'?plansView():S.page==='resources'?resourcesView():S.page==='reports'?reportsView():S.page==='chat'?chatPage():reviewView()}</main></div>${modalMarkup()}`;
}
function searchField(id,key,value){return `<label class="search-field">${icon('search')}<input id="${id}" type="search" aria-label="${t(key)}" placeholder="${t(key)}" value="${esc(value)}"></label>`}
function issueRows(){
 const q=S.query.trim().toLowerCase();
 return ISSUES.filter(i=>scopeMatches(res(i.resource))&&(S.filter==='all'||S.filter===i.status)&&[i.id,i.title.zh,i.title.en,res(i.resource).name].some(v=>v.toLowerCase().includes(q)));
}
function queueRow(i,isPlan=false){
 const p=PLANS.find(x=>x.issue===i.id),r=res(i.resource);
 return `<button class="queue-row ${i.id===S.issue?'active':''}" data-a="select-issue" data-issue="${i.id}" aria-pressed="${i.id===S.issue}"><div class="eyeline"><span class="mono">${isPlan?p.id:i.id}</span>${isPlan?badge(planStatus(p),planStatus(p)==='approved'?'green':''):badge(i.severity,'red')}</div><strong>${esc(tr(isPlan?p.title:i.title))}</strong><div class="row-meta"><span>${r.name}</span><span>${isPlan?'v'+p.version:t(i.status)}</span></div></button>`;
}
function issueQueue(){
 const rows=issueRows();return `<aside class="queue"><div class="queue-heading"><h1>${t('issues')}<small>${ISSUES.length}</small></h1>${searchField('issue-query','search',S.query)}<div class="filters">${['all','ready','needsEvidence'].map(k=>`<button class="${S.filter===k?'active':''}" data-a="issue-filter" data-value="${k}">${t(k)}</button>`).join('')}</div></div><div class="queue-items">${rows.map(i=>queueRow(i)).join('')||empty('noResults')}</div><div class="queue-footer">${t('showing')} ${rows.length} / ${ISSUES.length} ${t('rows')}</div></aside>`;
}
function empty(key,hint='emptySelectHint'){return `<div class="empty"><h2>${t(key)}</h2><p>${t(hint)}</p>${key==='noResults'?btn('clearFilters','clear-filters'):''}</div>`}
function tabs(items,value,action){return `<div class="tabbar" role="group" aria-label="${t('navigation')}">${items.map(([key,count])=>`<button data-a="${action}" data-tab="${key}" class="${value===key?'active':''}" aria-pressed="${value===key}">${t(key)}${count!==undefined?`<span>${count}</span>`:''}</button>`).join('')}</div>`}
function issueHead(){
 const i=issue(),r=res(i.resource),p=fix();
 return `<header class="object-header"><div class="eyeline"><span class="mono">${i.id}</span>${badge(i.severity,'red')}${badge(S.life[i.id]||'inProgress')}</div><div class="object-title"><h1>${esc(tr(i.title))}</h1><div class="object-actions">${p?btn('viewPlan','view-plan','','primary'):btn('notes','note','','primary')}<button class="btn" data-a="chat-drawer">${icon('chat')}${t('askAgent')}</button><button class="btn square" data-a="issue-menu" aria-label="${t('more')}">${icon('more')}</button></div></div><div class="object-meta"><span>${icon('resources')}<button class="link" data-a="resource-detail" data-resource="${r.id}">${r.name}</button></span><span>${r.account} / ${r.region}</span><span>${t('created')} ${fmt(i.time)} UTC+08:00</span></div><div class="state-line"><span>${t('issueState')}<b>${t(S.life[i.id]||'inProgress')}</b></span><span>${t('rcaState')}<b>${t(i.plan?'complete':'investigating')}</b></span><span>${t('planState')}<b>${t(p?planStatus(p):'noPlan')}</b></span><span>${t('runState')}<b>${t('notExecuted')}</b></span></div></header>`;
}
function pipeline(){
 const p=fix(),n=p?(planStatus(p)==='approved'?5:4):1,keys=['stepEvent','stepInvestigate','stepRca','stepPlan','stepReview','stepRun','stepVerify'];
 return `<details class="pipeline" data-open="pipeline-${S.issue}" ${S.open['pipeline-'+S.issue]?'open':''}><summary><span>${t('workflow')} · ${t(p?planStatus(p):'investigating')}</span><span>${t('expandProcess')}</span></summary><div class="stages">${keys.map((k,j)=>`<div class="stage ${j<n?'done':j===n?'current':''}"><i>${j<n?'✓':j+1}</i>${t(k)}</div>`).join('')}</div></details>`;
}
function planPreview(p){const r=res(p.resource);return `<div class="plan-preview"><div><div class="eyeline"><span class="mono">${p.id} · v${p.version}</span>${badge(planStatus(p))}${badge('notExecuted')}</div><h3>${esc(tr(p.title))}</h3><p>${t('target')}：${r.name} · ${r.account} / ${r.region}</p></div>${btn('reviewPlan','view-plan')}</div>`}
function overview(){
 const i=issue(),p=fix();return `<div class="finding"><h3>${t('conclusion')}</h3><p>${esc(tr(i.conclusion))}</p></div><div class="two-columns"><section class="text-section"><h3>${t('impact')}</h3><p>${esc(tr(i.impact))}</p></section><section class="text-section"><h3>${t('unknown')}</h3><p>${esc(tr(i.unknown))}</p></section></div><div class="section-heading"><h2>${t('relatedFix')}</h2><button class="link" data-a="issue-tab" data-tab="relatedPlans">${t('relatedPlans')}</button></div>${p?planPreview(p):`<div class="context-box"><p class="small">${esc(tr(i.next))}</p></div>`}<div class="section-heading"><h2>${t('evidence')}</h2><button class="link" data-a="issue-tab" data-tab="evidence">${t('allEvidence')}</button></div>${evidenceList(i.evidence.slice(0,2))}<div class="record-strip"><div><span>${t('evidenceCoverage')}</span><b>${i.evidence.filter(e=>e.kind!=='missing').length} / ${i.evidence.length} ${t('traceable')}</b></div><div><span>${t('verification')}</span><b>${t('unverified')}</b></div><div><span>${t('owner')}</span><b>${t('oncall')}</b></div></div>`;
}
function evidenceList(evs=issue().evidence){return evs.map(e=>`<details class="disclosure" data-open="${e.id}" ${S.open[e.id]?'open':''}><summary><span>${e.id} · ${esc(tr(e.title))}</span>${badge(e.kind==='missing'?'missing':'traceable',e.kind==='missing'?'amber':'')}</summary><div class="inside"><div class="source-row"><span>${t('source')}：${esc(tr(e.source))}</span><span>${e.time?fmt(e.time)+' UTC+08:00':''}</span></div>${e.raw?`<pre lang="en">${esc(e.raw)}</pre>`:''}<p>${esc(tr(e.meaning))}</p></div></details>`).join('')}
function rcaView(){const i=issue();return `<section class="text-section" style="border-top:0;padding-top:0"><h3>${t('explain')}</h3><p>${esc(tr(i.conclusion))}</p><p>${esc(tr(i.known))}</p></section>${evidenceList()}<div class="section-heading"><h2>${t('diagnosticQuality')}</h2></div><div class="record-strip"><div><span>${t('confidence')}</span><b>${i.plan?'95%':'—'}</b><small class="muted" style="display:block;margin-top:4px">${t('notProbability')}</small></div><div><span>${t('critic')}</span><b>${t(i.plan?'criticText':'criticMissing')}</b></div><div><span>${t('verification')}</span><b>${t('unverified')}</b></div></div><div class="toolbar-group" style="margin-top:18px">${btn('correct','operation','data-op="correct"')}${btn('incorrect','operation','data-op="incorrect"')}</div>`}
function noteEditor(modal=false){const id=modal?"issue-note-modal":"issue-note";return `<label class="dialog-label" for="${id}">${t('noteLabel')}</label><textarea id="${id}" class="note-input" placeholder="${t('notePlaceholder')}">${esc(S.notes[S.issue]||'')}</textarea><div class="note-actions"><span>${t('localOnly')}</span>${btn('saveNote','save-note')}</div>`}
function activity(){
 const i=issue(),items=[['received',i.time],['collected',i.evidence[0].time||i.time],['rcaPrepared','2026-10-01T01:54:00Z'],...(i.plan?[['planPrepared','2026-10-01T01:55:00Z']]:[])];
 return `<ol class="timeline">${items.map(([key,time])=>`<li><time>${fmt(time)} UTC+08:00</time><strong>${t(key)}</strong><p>${key==='received'?i.id:key==='planPrepared'?i.plan:'SRE Agent'}</p></li>`).join('')}${S.audit.filter(a=>a.issue===S.issue).map(a=>`<li><time>${fmt(a.time)} UTC+08:00</time><strong>${t(a.action)}</strong><p>${esc(a.reason||'')}</p></li>`).join('')}</ol>${noteEditor()}`;
}
function linkedResources(){const r=res(issue().resource),rs=[r,...r.depends.map(id=>res(id))];return resourceTable(rs,true)}
function issuesView(){
 const i=issue(),visible=issueRows().some(x=>x.id===i.id);
 let body=empty('emptySelect');
 if(visible){const sub=S.itab==='overview'?overview():S.itab==='rca'?rcaView():S.itab==='evidence'?evidenceList():S.itab==='timeline'?activity():S.itab==='relatedPlans'?(fix()?planPreview(fix()):empty('noPlan','noPlanHint')):S.itab==='relatedResources'?linkedResources():S.itab==='report'?(i.id===REPORT.issue?`<div class="finding"><h3>${t('interim')}</h3><p>${esc(tr(REPORT.summary))}</p></div>${btn('report','nav','data-page="reports"','primary')}`:empty('noReport','noReportHint')):overview();
 body=issueHead()+pipeline()+tabs([['overview'],['rca'],['evidence',i.evidence.length],['timeline'],['relatedPlans',i.plan?1:0],['relatedResources'],['report']],S.itab,'issue-tab')+`<section id="issue-content">${sub}</section>`}
 return `<div class="split-view">${issueQueue()}<div class="detail" id="detail">${body}</div></div>`;
}
function planRows(){
 const q=S.planQuery.toLowerCase(),arr=S.kind==='change'?[change]:PLANS;
 return arr.filter(p=>scopeMatches(res(p.resource))&&(S.risk==='all'||planRisk(p)===S.risk)&&[p.id,tr(p.title),res(p.resource).name].some(v=>v.toLowerCase().includes(q)));
}
function plansQueue(){
 const rows=planRows();return `<aside class="queue"><div class="queue-heading"><h1>${t(S.kind==='change'?'changePlans':'fixPlans')}<small>${S.kind==='change'?1:PLANS.length}</small></h1>${searchField('plan-query','search',S.planQuery)}<div class="filters"><select id="risk-filter" class="field" aria-label="${t('risk')}"><option value="all">${t('allRisks')}</option>${['L0','L1','L2','L3'].map(r=>`<option ${S.risk===r?'selected':''}>${r}</option>`).join('')}</select></div></div><div class="queue-items">${rows.map(p=>p.id==='C-041'?`<button class="queue-row active" data-a="select-change"><div class="eyeline"><span class="mono">${p.id}</span>${badge(planStatus(p))}</div><strong>${esc(tr(p.title))}</strong><div class="row-meta">orders-db · v2</div></button>`:queueRow(ISSUES.find(i=>i.id===p.issue),true)).join('')||empty('noResults')}</div><div class="queue-footer">${t('showing')} ${rows.length} ${t('rows')}</div></aside>`;
}
function checks(p,lang=S.lang){return `<table class="checks"><thead><tr><th>${t('check',lang)}</th><th>${t('passCondition',lang)}</th><th>${t('result',lang)}</th></tr></thead><tbody>${p.checks.map(([id,label])=>`<tr><td class="mono">${id}</td><td>${esc(tr(label,lang))}</td><td><span class="tag">${t('pending',lang)}</span></td></tr>`).join('')}</tbody></table>`}
function planOverview(p){
 const r=res(p.resource);
 return `<div class="plan-layout"><div><section class="text-section" style="border-top:0;padding-top:0"><h3>${t('why')}</h3><p>${esc(tr(p.why))}</p></section><h3>${t('what')}</h3><ol class="plan-steps">${p.steps.map(s=>`<li>${esc(tr(s))}</li>`).join('')}</ol><div class="risk-box"><b>${t('riskScope')}</b><br>${esc(tr(p.risk))}</div><h3>${t('verification')}</h3>${checks(p)}<section class="text-section"><h3>${t('rollback')}</h3><p>${esc(tr(p.rollback))}</p></section><details class="disclosure" data-open="commands-${p.id}" ${S.open['commands-'+p.id]?'open':''}><summary>${t('commands')}</summary><div class="inside"><pre lang="en">${esc(p.commands)}</pre><p>${t('localOnly')}</p></div></details></div><aside class="context-box plan-context"><h3>${t('target')}</h3><dl class="facts"><dt>${t('name')}</dt><dd>${r.name}</dd><dt>${t('account')}</dt><dd>${r.account}</dd><dt>${t('region')}</dt><dd>${r.region}</dd><dt>${t('version')}</dt><dd>${p.id} / v${p.version}</dd></dl><p class="small muted">${t('versionBound')}</p></aside></div>`;
}
function planDetail(){
 const p=selectedPlan();if(!p||!planRows().some(x=>x.id===p.id))return empty('emptySelect');
 const r=res(p.resource),status=planStatus(p);
 const head=`<header class="object-header"><div class="eyeline"><span class="mono">${p.id} · v${p.version}</span><span class="tag ${planRisk(p)==='L2'?'amber':''}">${planRisk(p)}</span>${badge(status,status==='approved'?'green':status==='rejected'?'red':'')}${badge('notExecuted')}</div><div class="object-title"><h1>${esc(tr(p.title))}</h1><div class="object-actions">${status==='pendingApproval'?btn('approve','operation','data-op="approve"','primary')+btn('reject','operation','data-op="reject"','danger'):status==='approved'?btn('execute','operation','data-op="execute"','primary'):btn('approval','plan-tab','data-tab="approval"')}</div></div><div class="object-meta"><span>${t(p.id==='C-041'?'source':'sourceIssue')}：${p.id==='C-041'?t('request'):`<button class="link" data-a="view-issue" data-issue="${p.issue}">${p.issue}</button>`}</span><span>${t('target')}：<button class="link" data-a="resource-detail" data-resource="${r.id}">${r.name}</button></span><span>${r.account} / ${r.region}</span></div></header>`;
 let content=planOverview(p);
 if(S.ptab==='approval'){const a=S.approvals[p.id];content=a?`<div class="context-box">${badge(a.status,a.status==='approved'?'green':'red')}<dl class="facts"><dt>${t('actor')}</dt><dd>demo-admin</dd><dt>${t('time')}</dt><dd>${fmt(a.time)} UTC+08:00</dd><dt>${t('version')}</dt><dd>${p.id} / v${p.version}</dd><dt>${t('reason')}</dt><dd>${esc(a.reason||'—')}</dd></dl><p class="small muted">${t('localOnly')}</p></div>`:empty('noApproval','noApprovalHint')}
 if(S.ptab==='execution')content=(S.runRequests[p.id]?`<div class="context-box"><h3>${t('requestRecorded')}</h3><p class="small">${t('requestRecordedHint')}</p><p class="mono">${p.id} / v${p.version}</p></div>`:'')+empty('noExecution','noExecutionHint')+checks(p);
 return head+tabs([['overview'],['approval'],['execution']],S.ptab,'plan-tab')+content+`<p class="small muted" style="margin-top:22px">${t('versionBound')}</p>`;
}
function auditTable(){
 const records=[{action:'rcaPrepared',object:'I-2401',actor:'SRE Agent',time:'2026-10-01T01:54:00Z'},{action:'planPrepared',object:'P-126 / v3',actor:'SRE Agent',time:'2026-10-01T01:55:00Z'},...S.audit];
 return `<div class="table-wrap"><table class="data-table"><thead><tr>${['time','object','action','actor','reason'].map(k=>`<th>${t(k)}</th>`).join('')}</tr></thead><tbody>${records.map(a=>`<tr><td>${fmt(a.time)} UTC+08:00</td><td class="mono">${esc(a.object)}</td><td>${t(a.action)}</td><td>${a.actor||'demo-admin'}</td><td>${esc(a.reason||'—')}</td></tr>`).join('')}</tbody></table></div>`;
}
function plansView(){return `<div class="plans-heading"><div class="page-heading"><div><h1>${t('plans')}</h1><p>${t('plansIntro')}</p></div></div>${tabs([['fixPlans',2],['changePlans',1],['audit']],{fix:'fixPlans',change:'changePlans',audit:'audit'}[S.kind],'plan-kind')}</div>${S.kind==='audit'?`<div class="page-body">${auditTable()}</div>`:`<div class="split-view">${plansQueue()}<div class="detail">${planDetail()}</div></div>`}`}
function resourceRows(){
 const q=S.resourceQuery.toLowerCase();return RESOURCES.filter(r=>scopeMatches(r)&&(S.resourceType==='all'||r.type===S.resourceType)&&[r.name,r.native,r.account,r.region,r.type].some(x=>x.toLowerCase().includes(q)));
}
function resourceTable(rows,compact=false){
 const columns=compact?['type','account','health']:Object.keys(S.columns).filter(k=>S.columns[k]);
 return `<div class="table-wrap"><table class="data-table ${compact?'compact':''}"><thead><tr><th>${t('name')}</th>${columns.map(k=>`<th>${t(k)}</th>`).join('')}<th>${t('relatedIssues')}</th></tr></thead><tbody>${rows.map(r=>`<tr><td><button class="link cell-title" data-a="resource-detail" data-resource="${r.id}">${r.name}</button><span class="secondary-line mono">${r.native}</span></td>${columns.map(k=>`<td>${k==='health'?badge(r.health,['critical','high'].includes(r.health)?'red':r.health==='healthy'?'green':'amber'):k==='observed'?fmt(r.time):esc(r[k])}</td>`).join('')}<td>${r.issues.length?r.issues.map(id=>`<button class="link mono" data-a="view-issue" data-issue="${id}">${id}</button>`).join(', '):'—'}</td></tr>`).join('')}</tbody></table></div>`;
}
function resourceDetail(){
 const r=res(),linked=r.issues.map(id=>ISSUES.find(i=>i.id===id));
 const overviewHTML=`<div class="resource-hero"><div class="two-columns"><section><h2>${t('identity')}</h2><dl class="facts"><dt>${t('nativeId')}</dt><dd class="mono">${r.native}</dd><dt>${t('account')}</dt><dd>${r.account}</dd><dt>${t('region')}</dt><dd>${r.region}</dd><dt>${t('service')}</dt><dd>${esc(tr(r.serviceLabel))}</dd></dl></section><section class="health-info"><h2>${t('health')}</h2><div class="health-pair"><div><span>${t('lifecycle')}</span>${badge(r.state)}</div><div><span>${t('health')}</span>${badge(r.health,r.health==='critical'?'red':r.health==='healthy'?'green':'amber')}</div></div><p class="small">${esc(tr(r.summary))}</p><p class="small muted" style="margin-top:12px">${t('observed')} ${fmt(r.time)} UTC+08:00</p></section></div></div><div class="section-heading"><h2>${t('relatedIssues')}</h2></div>${linked.length?linked.map(i=>`<div class="plan-preview" style="margin-bottom:12px"><div><div class="eyeline"><span class="mono">${i.id}</span>${badge(i.severity,'red')}</div><h3>${esc(tr(i.title))}</h3><p>${esc(tr(i.impact))}</p></div>${btn('issues','view-issue',`data-issue="${i.id}"`)}</div>`).join(''):empty('noIssues','noIssuesHint')}`;
 let sub=overviewHTML;
 if(S.rtab==='relatedIssues')sub=linked.length?`<div class="table-wrap"><table class="data-table compact"><thead><tr><th>ID</th><th>${t('issues')}</th><th>${t('issueState')}</th></tr></thead><tbody>${linked.map(i=>`<tr><td class="mono">${i.id}</td><td><button class="link" data-a="view-issue" data-issue="${i.id}">${esc(tr(i.title))}</button></td><td>${badge(i.status)}</td></tr>`).join('')}</tbody></table></div>`:empty('noIssues','noIssuesHint');
 if(S.rtab==='relatedPlans')sub=linked.some(i=>i.plan)?linked.filter(i=>i.plan).map(i=>`<div class="plan-preview"><div><span class="mono">${i.plan}</span><h3>${esc(tr(PLANS.find(p=>p.id===i.plan).title))}</h3></div>${btn('viewPlan','linked-plan',`data-issue="${i.id}"`)}</div>`).join(''):empty('noPlan','noPlanHint');
 if(S.rtab==='network')sub=`<div class="view-panel"><h2>${t('network')}</h2>${r.depends.length?`<div class="dependency">${(r.id==='web'?['lb','web','db']:[r.id,...r.depends]).map((id,index)=>`${index?'<span>→</span>':''}<button class="${id===r.id?'focus':''}" data-a="resource-detail" data-resource="${id}">${res(id).name}</button>`).join('')}</div>`:`<p class="small muted" style="margin-top:20px">${t('noDependencies')}</p>`}<p class="small muted">${t('dependencyHint')}</p></div>`;
 if(S.rtab==='tags')sub=`<div class="view-panel"><h2>${t('tags')}</h2><dl class="facts"><dt>service</dt><dd>${r.service}</dd><dt>environment</dt><dd>production</dd><dt>owner</dt><dd>sre-team</dd></dl></div>`;
 if(S.rtab==='raw')sub=`<div class="view-panel"><h2>${t('raw')}</h2><pre class="raw" lang="en">${esc(JSON.stringify({resource_uid:'res-demo-'+r.id,native_id:r.native,provider:'aws',account:r.account,region:r.region,type:r.type,observed_at:r.time,tags:{service:r.service,environment:'production'}},null,2))}</pre></div>`;
 return `<div class="page-body"><button class="link small" data-a="resource-list">${t('backResources')}</button><header class="object-header" style="margin-top:20px"><div class="eyeline"><span>${r.type} / ${r.account}</span>${badge(r.health,r.health==='critical'?'red':r.health==='healthy'?'green':'amber')}</div><div class="object-title"><h1>${r.name}</h1><div class="object-actions">${linked.length?btn('askAgent','resource-chat','', ''):''}</div></div><div class="object-meta"><span class="mono">${r.native}</span><span>${r.region}</span><span>${t('observed')} ${fmt(r.time)} UTC+08:00</span></div></header>${tabs([['overview'],['relatedIssues',linked.length],['relatedPlans'],['network'],['tags'],['raw']],S.rtab,'resource-tab')}${sub}</div>`;
}
function resourcesView(){if(S.rview==='detail')return resourceDetail();const rows=resourceRows();return `<div class="page-body"><div class="page-heading"><div><h1>${t('resources')}</h1><p>${t('resourceIntro')}</p></div>${btn('columns','columns')}</div><div class="toolbar" style="margin-bottom:18px"><div class="toolbar-group">${searchField('resource-query','resourceSearch',S.resourceQuery)}<select id="resource-type" class="field" aria-label="${t('type')}"><option value="all">${t('allTypes')}</option>${['EC2','RDS','ALB'].map(x=>`<option ${S.resourceType===x?'selected':''}>${x}</option>`).join('')}</select></div><span class="small muted">${t('resourceCount')} ${RESOURCES.length}</span></div>${rows.length?resourceTable(rows):empty('noResults')}<div class="table-note"><span>${t('showing')} ${rows.length} / ${RESOURCES.length} ${t('rows')}</span><span>UTC+08:00</span></div></div>`}
function reportPaper(lang=S.lang){
 const i=ISSUES[0],p=PLANS[0],r=res('web'),T=k=>t(k,lang);
 return `<article class="paper" lang="${lang==='zh'?'zh-CN':'en'}" data-report-language="${lang}"><div class="paper-brand"><b>AgenticOps</b><span>${REPORT.id} / v${REPORT.version}</span></div><span class="tag">${T('interim')}</span><h1>${esc(tr(UI.reportTitle,lang))}</h1><dl class="facts"><dt>${T('target')}</dt><dd>${r.name} / ${r.account} / ${r.region}</dd><dt>${T('observedWindow')}</dt><dd>${fmt(REPORT.from,lang)} – ${fmt(REPORT.to,lang)} UTC+08:00</dd><dt>${T('generated')}</dt><dd>${fmt(REPORT.generated,lang)} UTC+08:00</dd><dt>${T('sourceIssue')}</dt><dd>${i.id} / ${p.id} v${p.version}</dd></dl><div class="finding"><p>${esc(tr(REPORT.summary,lang))}</p></div><h2>${T('conclusion')}</h2><p>${esc(tr(i.conclusion,lang))} <a href="#${lang}-E-301">[E-301]</a> <a href="#${lang}-E-302">[E-302]</a></p><h2>${T('impact')}</h2><p>${esc(tr(i.impact,lang))}</p><h2>${T('actions')}</h2><ol>${REPORT.actions.map(a=>`<li>${esc(tr(a,lang))}</li>`).join('')}</ol><h2>${T('verification')}</h2>${checks(p,lang)}<h2>${T('evidenceIndex')}</h2>${i.evidence.map(e=>`<section id="${lang}-${e.id}" style="margin:18px 0"><h3>${e.id} · ${esc(tr(e.title,lang))}</h3><p>${esc(tr(e.meaning,lang))}</p>${e.raw?`<details class="disclosure" data-open="report-${e.id}" ${S.open['report-'+e.id]?'open':''}><summary>${T('rawEvidence')}</summary><div class="inside"><pre lang="en">${esc(e.raw)}</pre></div></details>`:''}</section>`).join('')}<h2>${T('limitations')}</h2><p>${esc(tr(REPORT.limitations,lang))}</p><div class="paper-footer">${T('reportNote')}<br>${T('prototype')}</div></article>`;
}
function reportsView(){return `<div class="page-body"><div class="page-heading"><div><h1>${t('reports')}</h1><p>${t('reportsIntro')}</p></div></div><div class="report-layout"><aside class="report-list"><button data-a="report-select"><span class="mono">${REPORT.id}</span><strong>${t('reportTitle')}</strong><small>v2 / ${t('interim')}<br>I-2401 / P-126 v3</small></button></aside><div><div class="report-toolbar"><div class="segmented" role="group" aria-label="${t('currentLanguage')}">${['current','both'].map(k=>`<button data-a="report-mode" data-mode="${k}" class="${S.reportMode===k?'active':''}" aria-pressed="${S.reportMode===k}">${t(k==='current'?'currentLanguage':'bilingual')}</button>`).join('')}</div><div class="toolbar-group">${btn('export','export','','primary')}${btn('print','print')}${btn('share','share')}${btn('publish','operation','data-op="publish"')}</div></div><div class="papers ${S.reportMode==='both'?'both':''}" id="papers">${S.reportMode==='both'?reportPaper('zh')+reportPaper('en'):reportPaper()}</div></div></div></div>`}
function activeChat(){return S.sessions.find(c=>c.id===(S.modal?.type==='chat'?S.issue:S.chatId))||S.sessions[0]}
function ensureMessages(c=activeChat()){if(!S.messages[c.id])S.messages[c.id]=c.issue?[{role:'user',key:'seedQuestion'},{role:'agent',seed:true}]:[]}
function chatTitle(c){return c.issue?tr(ISSUES.find(i=>i.id===c.issue).short):c.title||(S.drafts[c.id]?.trim().slice(0,54))||t('untitledChat')}
function attachmentsMarkup(files,remove=false){return files.map(f=>`<div class="attachment">${f.url?`<img src="${esc(f.url)}" alt="${esc(f.name)}">`:icon('reports')}<span>${esc(f.name)}</span>${remove?`<button data-a="remove-file" data-id="${f.id}" aria-label="${t('removeAttachment')}">×</button>`:''}</div>`).join('')}
function chatContents(){
 const c=activeChat();ensureMessages(c);const i=c.issue?ISSUES.find(i=>i.id===c.issue):null,r=i?res(i.resource):null,isEmpty=!i&&!S.messages[c.id].length;
 const composer=`<div class="chat-composer"><small>${i?`${t('linkedContext')}：${i.id} / ${r.name}${i.plan?' / '+i.plan:''}`:`${t('requestScope')}：${c.scope==='all'?t('allScopes'):c.scope}${S.messages[c.id].length?' · '+t('scopeBound'):''}`}</small><div class="attachments">${attachmentsMarkup(S.files[c.id]||[],true)}</div><textarea id="chat-input" aria-label="${t(i?'chatInput':'requestInput')}" placeholder="${t(i?'chatInput':'requestInput')}">${esc(S.drafts[c.id]||'')}</textarea><div class="toolbar"><input type="file" id="chat-file" hidden multiple accept=".png,.jpg,.jpeg,.gif,.webp,.pdf,.doc,.docx,.xls,.xlsx,.html,.txt,.md,.log,.csv,.json,.yaml,.yml,.tf,.hcl"><button class="link" data-a="attach">${icon('attach')}${t('attachments')}</button>${btn('send','send-chat',`id="send-chat" ${!(S.drafts[c.id]?.trim()||S.files[c.id]?.length)?'disabled':''}`,'primary')}</div></div>`;
 if(isEmpty)return `<div class="request-start"><div class="request-heading"><span class="request-mark">${icon('brand')}</span><h1>${t('requestTitle')}</h1><p>${t('requestHint')}</p></div>${composer}<div class="request-prompts">${['promptInvestigate','promptChange','promptReport'].map(k=>`<button data-a="prompt" data-prompt="${k}">${t(k)}<span aria-hidden="true">↗</span></button>`).join('')}</div><p class="chat-hint">${t('chatLocal')} ${t('materialLimits')}</p></div>`;
 return `<div class="chat-transcript" id="chat-transcript">${S.messages[c.id].map(m=>m.role==='user'?`<div class="message user"><div class="user-bubble">${m.key?t(m.key):esc(m.text)}${m.files?.length?`<div class="attachments">${attachmentsMarkup(m.files)}</div>`:''}</div></div>`:`<div class="message agent"><div class="message-name"><i>SRE</i><b>${t('agent')}</b><span>${t('sampleReply')}</span></div><p>${m.seed?esc(tr(i.conclusion)):m.files?t('fileReply'):t(i?'chatReply':'requestReply')}</p>${m.seed?`<div class="chat-chips">${i.evidence.map(e=>`<button data-a="chat-evidence" data-issue="${i.id}" data-evidence="${e.id}">${e.id} · ${esc(tr(e.title))}</button>`).join('')}</div><p>${esc(tr(i.unknown))}</p>${i.plan?`<div style="margin-top:15px">${btn('viewPlan','view-plan',`data-issue="${i.id}"`)}</div>`:''}`:''}</div>`).join('')}</div>${composer}<p class="chat-hint">${t('chatLocal')} ${t('materialLimits')}</p>`;
}
function chatPage(){
 const c=activeChat(),i=c.issue?ISSUES.find(x=>x.id===c.issue):null;ensureMessages(c);const isEmpty=!i&&!S.messages[c.id].length;
 return `<div class="chat-layout"><aside class="conversation-list"><div class="conversation-heading"><h2>${t('chat')}</h2>${btn('newChat','new-chat')}</div><div class="small muted session-label">${t('recentChats')}</div><div class="session-items">${S.sessions.map(x=>`<button class="queue-row ${x.id===c.id?'active':''}" data-a="select-chat" data-chat="${x.id}" ${x.issue?`data-issue="${x.issue}"`:''} aria-pressed="${x.id===c.id}"><strong>${esc(chatTitle(x))}</strong><span class="small muted">${x.issue?x.issue+' · '+res(ISSUES.find(i=>i.id===x.issue).resource).name:t(S.messages[x.id]?.length?'unlinkedChat':'draft')}</span></button>`).join('')}</div></aside><section class="chat-view ${isEmpty?'request-empty':''}">${isEmpty?'':`<header class="object-header"><div class="eyeline">${i?`<span class="mono">${i.id}</span><span>${t('newContext')}</span>`:t('unlinkedChat')}</div><div class="object-title"><h1>${esc(chatTitle(c))}</h1>${i?btn('backIssue','view-issue',`data-issue="${i.id}"`):''}</div>${i?`<p class="small muted">${t('conversationHint')}</p>`:''}</header>`}${chatContents()}</section></div>`;
}
function newChat(){
 let c=S.sessions.find(x=>!x.issue&&!S.messages[x.id]?.length&&!S.drafts[x.id]?.trim()&&!S.files[x.id]?.length);
 if(!c){c={id:'request-'+S.nextChat++,issue:null,title:null,scope:S.scope};S.sessions.unshift(c)}
 go('chat',{chatId:c.id});document.getElementById('chat-input')?.focus({preventScroll:true});
}
function reviewView(){
 const items=[
 ['issues',say('RCA、证据、反馈、误报、关闭、关联方案与报告。','RCA, evidence, feedback, false positives, dismissal, plans and reports.'),say('列表—详情布局；状态分开；七步流程可展开；次级操作位置固定。','Stable list/detail layout, separate states, expandable workflow and consistent secondary actions.')],
 ['plans',say('Fix Plan、Change Plan、Audit，以及审批、驳回和执行入口。','Fix Plan, Change Plan, Audit, approval, rejection and execution actions.'),say('两类方案分开；目标与版本突出；验证和回滚进入主要阅读顺序。','Separate plan types, clear targets and versions, with verification and rollback in the main reading order.')],
 ['resources',say('属性、标签、网络关系、事件与方案关联。','Attributes, tags, network relationships, linked issues and plans.'),say('资源清单与详情分开；统一身份字段；运行状态和健康分开表达。','Separate inventory and detail views, consistent identity fields, and distinct lifecycle and health.')],
 ['chat',say('独立需求、事件对话、新建会话和附件入口。','Independent requests, case conversations, new chats and attachment controls.'),say('作为默认首页直接提出需求。每个会话分别保留草稿和范围，事件内按需打开对话。','Start a request directly from the default home. Each conversation keeps its own draft and scope; case chat opens on demand.')],
 ['reports',say('正文、发布、分享、导出和打印。','Report content, publishing, sharing, export and printing.'),say('文档式排版；统一工具栏；中英文与中英对照导出。','Document layout, a consistent toolbar, and Chinese, English and bilingual exports.')]
 ];
 return `<div class="page-body"><div class="page-heading"><div><h1>${t('designTitle')}</h1><p>${t('designIntro')}</p></div></div><div class="review-grid">${items.map(([k,keep,improve])=>`<div class="context-box"><h3>${t(k)}</h3><p><b>${t('preserved')}：</b>${keep}</p><p><b>${t('improved')}：</b>${improve}</p><div style="margin-top:14px">${btn(k,'nav',`data-page="${k}"`)}</div></div>`).join('')}<div class="context-box"><h3>${t('demoBoundary')}</h3><p>${t('demoBoundaryText')}</p></div></div><div class="section-heading"><h2>${t('retained')}</h2></div><div class="table-wrap"><table class="data-table"><thead><tr><th>${t('navigation')}</th><th>${t('preserved')}</th></tr></thead><tbody>${navEntries.map(([k,path])=>`<tr><td>${t(k)}</td><td>${path?`<a href="http://127.0.0.1:8000${path}" target="_blank" rel="noopener">${t('existing')} ↗</a>`:`<button class="link" data-a="nav" data-page="${k}">${say('查看本次样式范本','View the refined prototype')}</button>`}</td></tr>`).join('')}</tbody></table></div></div>`;
}
function attentionItems(){
 const rows=PLANS.filter(p=>planStatus(p)==='pendingApproval').map(p=>({label:tr(p.title),meta:p.id+' · '+t('pendingApproval'),a:'linked-plan',attrs:`data-issue="${p.issue}"`}));
 if(planStatus(change)==='pendingApproval')rows.push({label:tr(change.title),meta:change.id+' · '+t('pendingApproval'),a:'attention-change',attrs:''});
 rows.push(...ISSUES.filter(i=>!i.plan&&!S.life[i.id]).map(i=>({label:tr(i.short),meta:i.id+' · '+t('needsEvidence'),a:'view-issue',attrs:`data-issue="${i.id}"`})));
 return rows;
}
function modalMarkup(){
 if(!S.modal)return '';
 const close=`<button class="btn square" data-a="close-modal" aria-label="${t('close')}">×</button>`;
 if(S.modal.type==='preferences')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('preferences')}</h2>${close}</div><p>${t('preferencesHint')}</p><label class="preference-field"><span>${t('homeChoice')}</span><select id="home-choice">${['resume','chat','issues','reports'].map(k=>`<option value="${k}" ${S.home===k?'selected':''}>${t(k)}</option>`).join('')}</select></label><p class="small">${t('preferencesLocal')}</p><div class="dialog-actions">${btn('savePreferences','save-preferences','','primary')}</div></dialog>`;
 if(S.modal.type==='attention')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('attention')}</h2>${close}</div><div class="attention-list">${attentionItems().map(x=>`<button class="attention-item" data-a="${x.a}" ${x.attrs}><strong>${esc(x.label)}</strong><small>${esc(x.meta)}</small></button>`).join('')}</div><p class="chat-hint">${t('prototype')}</p></dialog>`;
 if(S.modal.type==='chat')return `<dialog class="drawer" id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('askAgent')}</h2>${close}</div><div class="eyeline" style="margin-bottom:19px">${S.issue} / ${res(issue().resource).name}<button class="link" data-a="full-chat">${t('openChatPage')}</button></div>${chatContents()}</dialog>`;
 if(S.modal.type==='menu')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('more')}</h2>${close}</div><p>${S.issue} · ${esc(tr(issue().title))}</p><div class="menu">${['resolve','falsePositive','dismiss','correct','incorrect','notes'].map(k=>`<button data-a="${k==='notes'?'note':'operation'}" data-op="${k}">${t(k)}</button>`).join('')}</div></dialog>`;
 if(S.modal.type==='note')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('notes')}</h2>${close}</div><p>${S.issue}</p>${noteEditor(true)}</dialog>`;
 if(S.modal.type==='columns')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('columns')}</h2>${close}</div>${Object.keys(S.columns).map(k=>`<label class="check-label"><input type="checkbox" data-column="${k}" ${S.columns[k]?'checked':''}>${t(k)}</label>`).join('')}<div class="dialog-actions">${btn('close','close-modal')}</div></dialog>`;
 if(S.modal.type==='share')return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('share')}</h2>${close}</div><p>${t('shareHint')}</p><label class="field-label" for="share-url">${REPORT.id} / v${REPORT.version} / ${S.lang}</label><input id="share-url" class="field" style="width:100%" readonly value="${esc(location.href)}"><div class="dialog-actions">${btn('close','close-modal')}</div></dialog>`;
 if(S.modal.type==='search')return `<dialog id="ref-modal" class="search-dialog" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t('globalSearch')}</h2>${close}</div>${searchField('search-all','globalSearch',S.search)}<div>${globalResults()}</div></dialog>`;
 const op=S.modal.op,p=S.modal.planId?[...PLANS,change].find(p=>p.id===S.modal.planId):null,needsCheck=['approve','execute'].includes(op);
 return `<dialog id="ref-modal" aria-labelledby="dialog-title"><div class="dialog-header"><h2 id="dialog-title">${t(op)}</h2>${close}</div><p>${t('reviewIntro')}</p><div class="context-box">${p?`<span class="mono">${p.id} / v${p.version}</span><h3 style="margin-top:7px">${esc(tr(p.title))}</h3><dl class="facts"><dt>${t('target')}</dt><dd>${res(p.resource).name}</dd><dt>${t('account')}</dt><dd>${res(p.resource).account}</dd><dt>${t('region')}</dt><dd>${res(p.resource).region}</dd></dl><p>${esc(tr(p.risk))}</p>`:op==='publish'?`<span class="mono">${REPORT.id} / v${REPORT.version} / ${S.reportMode==='both'?'zh-en':S.lang}</span><h3>${t('reportTitle')}</h3>`:`<span class="mono">${S.issue}</span><h3>${esc(tr(issue().title))}</h3>`}</div><label class="dialog-label" for="operation-reason">${t('reason')}${op==='reject'?' *':''}</label><textarea class="note-input" id="operation-reason">${esc(S.reason)}</textarea>${needsCheck?`<label class="check-label"><input id="version-check" type="checkbox" ${S.checked?'checked':''}>${t('confirmVersion')}</label>`:''}${S.error?`<div class="error" role="alert">${t(S.error)}</div>`:''}<div class="dialog-actions">${btn('cancel','close-modal')}${btn('recordDemo','confirm-operation','','primary')}</div></dialog>`;
}
function globalResults(){
 const q=S.search.toLowerCase(),rows=[...ISSUES.map(i=>({kind:'issues',id:i.id,label:tr(i.title),res:i.resource})),...PLANS.map(p=>({kind:'plans',id:p.id,label:tr(p.title),issue:p.issue})),{kind:'plans',id:change.id,label:tr(change.title)},...RESOURCES.map(r=>({kind:'resources',id:r.id,label:r.name+' / '+r.native}))].filter(x=>(x.id+' '+x.label).toLowerCase().includes(q));
 return rows.length?rows.map(x=>`<button class="search-result" data-a="search-result" data-kind="${x.kind}" data-id="${x.id}"><span><b>${esc(x.label)}</b><small style="display:block">${x.id}</small></span><small>${t(x.kind)}</small></button>`).join(''):empty('noResults');
}
let push=false,lastTrigger=null;
const routeFields=['page','lang','issue','resource','chatId','itab','ptab','rtab','kind','rview','scope','filter','query','planQuery','resourceQuery','resourceType','risk'];
function writeURL(){const route=Object.fromEntries(routeFields.map(k=>[k,S[k]]));const q=new URLSearchParams({page:S.page,lang:S.lang,issue:S.issue,resource:S.resource,chat:S.chatId,itab:S.itab,ptab:S.ptab,rtab:S.rtab,kind:S.kind,view:S.rview,scope:S.scope});history[push?'pushState':'replaceState'](route,'','?'+q);push=false;try{localStorage.setItem(preferenceKey,JSON.stringify({home:S.home,lang:S.lang,last:Object.fromEntries(q)}))}catch{}}
function render(options={}){
 const y=scrollY,active=document.activeElement,focus=active?.id,sel=active instanceof HTMLInputElement||active instanceof HTMLTextAreaElement?[active.selectionStart,active.selectionEnd]:null,chatScroll=document.getElementById('chat-transcript')?.scrollTop||0;
 document.documentElement.lang=S.lang==='zh'?'zh-CN':'en';document.title='AgenticOps · '+t(S.page);
 document.getElementById('refinement').innerHTML=frame();writeURL();
 const modal=document.getElementById('ref-modal');if(modal){modal.showModal();modal.addEventListener('cancel',e=>{e.preventDefault();closeModal()})}
 const target=focus&&document.getElementById(focus);if(target){target.focus({preventScroll:true});if(sel&&sel[0]!==null&&target.setSelectionRange)target.setSelectionRange(...sel)}
 const transcript=document.getElementById('chat-transcript');if(transcript)transcript.scrollTop=options.chatBottom?transcript.scrollHeight:chatScroll;
 if(options.keepScroll!==false)scrollTo(0,y);
}
function go(page,props={}){
 Object.assign(S,props);S.page=page;S.modal=null;push=true;
 if(['plans','resources'].includes(page))S.navOpen.tools=true;
 if(page==='resources'&&!('rview' in props))S.rview='list';
 render({keepScroll:false});scrollTo(0,0);
}
function chooseIssue(id){const i=ISSUES.find(x=>x.id===id);if(!i)return;S.issue=id;S.resource=i.resource;S.itab='overview';S.ptab='overview';S.modal=null}
function openModal(modal){lastTrigger=document.activeElement?.dataset.a;S.modal=modal;S.error='';S.reason='';S.checked=false;render();if(modal.type==='search')document.getElementById('search-all')?.focus()}
function closeModal(){S.modal=null;S.error='';render();document.querySelector(`[data-a="${lastTrigger}"]`)?.focus({preventScroll:true})}
function toast(message){let e=document.getElementById('toast');if(!e){e=document.createElement('div');e.id='toast';e.className='toast';e.setAttribute('role','status');document.body.append(e)}e.textContent=message;e.hidden=false;clearTimeout(window.refToast);window.refToast=setTimeout(()=>e.hidden=true,5500)}
function openPlan(id=S.issue){chooseIssue(id);S.kind='fix';S.scope='all';S.planQuery='';S.risk='all';go('plans',{ptab:'overview'})}
function performOperation(){
 const {op,planId}=S.modal,p=planId?[...PLANS,change].find(x=>x.id===planId):null;
 if(op==='reject'&&!S.reason.trim()){S.error='rejectNoReason';render();return}
 if(['approve','execute'].includes(op)&&!S.checked){S.error='checkRequired';render();return}
 const now=new Date().toISOString(),record={action:op,object:p?`${p.id} / v${p.version}`:op==='publish'?`${REPORT.id} / v${REPORT.version}`:S.issue,issue:S.issue,actor:'demo-admin',reason:S.reason,time:now};
 S.audit.push(record);
 if(op==='approve'||op==='reject')S.approvals[p.id]={status:op==='approve'?'approved':'rejected',reason:S.reason,time:now};
 if(op==='execute')S.runRequests[p.id]={time:now,version:p.version};
 if(op==='resolve')S.life[S.issue]='manualResolved';
 if(['falsePositive','dismiss'].includes(op))S.life[S.issue]='dismissed';
 closeModal();toast(t('saved'));
}
function sendChat(){
 const c=activeChat(),text=(S.drafts[c.id]||'').trim(),files=S.files[c.id]||[];if(!text&&!files.length)return;
 ensureMessages(c);if(!c.issue&&!c.title)c.title=(text||files[0]?.name||t('untitledChat')).slice(0,90);
 S.messages[c.id].push({role:'user',...(text?{text}:{key:'attachmentOnly'}),files:[...files]},{role:'agent',files:files.length>0});S.drafts[c.id]='';S.files[c.id]=[];render({chatBottom:true});document.getElementById('chat-input')?.focus({preventScroll:true});
}
function addFiles(files){
 const id=activeChat().id,target=S.files[id]||(S.files[id]=[]);for(const f of files){if(target.length>=5){toast(t('tooMany'));break}const ext=f.name.split('.').pop().toLowerCase(),limit=['png','jpg','jpeg','gif','webp','pdf','csv','doc','docx','xls','xlsx','html','txt','md'].includes(ext)?5*1024*1024:512*1024;if(f.size>limit){toast(t('tooLarge'));continue}target.push({id:String(S.nextFile++),name:f.name,url:f.type.startsWith('image/')?URL.createObjectURL(f):null})}render();
}
const exportCSS=`body{font:14px/1.85 -apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;color:#0f172a;max-width:940px;margin:30px auto;padding:0 20px}h1{font-size:29px;line-height:1.4}h2{font-size:20px;margin-top:28px}h3{font-size:15px}.paper-brand{display:flex;justify-content:space-between;border-bottom:2px solid #1e40af;padding-bottom:12px}.tag{font-size:11px;background:#eff5f6;padding:3px 6px}.facts{display:grid;grid-template-columns:125px 1fr;gap:9px;font-size:12px}dt{color:#66808b}dd{margin:0}.finding{border-left:3px solid #2563eb;background:#eff6ff;padding:12px 18px;margin:24px 0}.checks{width:100%;border-collapse:collapse;font-size:12px}.checks th,.checks td{border-bottom:1px solid #dce5e9;text-align:left;padding:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:11px/1.7 ui-monospace,monospace;background:#f1f6f8;padding:13px}summary{cursor:pointer}.paper-footer{font-size:11px;border-top:1px solid #d2e0e5;padding-top:15px;margin-top:30px}a{color:#1d4ed8}.paper+.paper{margin-top:65px;padding-top:25px;border-top:2px solid #1e40af}@media(max-width:600px){.facts{grid-template-columns:1fr;gap:3px}dd{margin-bottom:10px}}@media print{@page{size:A4;margin:16mm}body{margin:0;padding:0;max-width:none;font-size:10pt}.paper+.paper{break-before:page;border:0;padding:0;margin:0}h2{break-after:avoid}tr{break-inside:avoid}}`;
function exportReport(){
 const languages=S.reportMode==='both'?['zh','en']:[S.lang],mode=S.reportMode==='both'?'zh-en':S.lang,content=languages.map(l=>reportPaper(l)).join('');
 const html=`<!doctype html><html lang="${S.lang==='zh'?'zh-CN':'en'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AgenticOps ${REPORT.id} v${REPORT.version} ${mode}</title><style>${exportCSS}</style></head><body>${content}</body></html>`,url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=`AgenticOps_${REPORT.id}_v${REPORT.version}_${mode}.html`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);toast(t('reportExported'));
}
document.addEventListener('click',e=>{
 const el=e.target.closest('[data-a]');if(!el||el.disabled)return;const a=el.dataset.a;
 if(a==='lang'){S.lang=el.dataset.lang;render();document.querySelector(`[data-a="lang"][data-lang="${S.lang}"]`)?.focus({preventScroll:true})}
 else if(a==='nav')go(el.dataset.page);
 else if(a==='preferences')openModal({type:'preferences'});
 else if(a==='attention')openModal({type:'attention'});
 else if(a==='attention-change'){S.kind='change';go('plans',{ptab:'overview'})}
 else if(a==='save-preferences'){S.home=document.getElementById('home-choice').value;closeModal();toast(t('preferencesSaved'))}
 else if(a==='select-issue'){chooseIssue(el.dataset.issue);render()}
 else if(a==='view-issue'){chooseIssue(el.dataset.issue);S.scope='all';S.query='';S.filter='all';go('issues')}
 else if(a==='view-plan')openPlan(el.dataset.issue||S.issue);
 else if(a==='linked-plan')openPlan(el.dataset.issue);
 else if(a==='issue-tab'){S.itab=el.dataset.tab;render()}
 else if(a==='plan-tab'){S.ptab=el.dataset.tab;render()}
 else if(a==='resource-tab'){S.rtab=el.dataset.tab;render()}
 else if(a==='issue-filter'){S.filter=el.dataset.value;render()}
 else if(a==='clear-filters'){S.query='';S.planQuery='';S.resourceQuery='';S.filter='all';S.scope='all';S.risk='all';S.resourceType='all';render()}
 else if(a==='plan-kind'){S.kind={fixPlans:'fix',changePlans:'change',audit:'audit'}[el.dataset.tab];S.ptab='overview';S.planQuery='';S.risk='all';render()}
 else if(a==='select-change'){S.kind='change';S.ptab='overview';render()}
 else if(a==='resource-detail'){S.resource=el.dataset.resource;go('resources',{rview:'detail',rtab:'overview'})}
 else if(a==='resource-list')go('resources',{rview:'list'});
 else if(a==='resource-chat'){if(res().issues.length){chooseIssue(res().issues[0]);openModal({type:'chat'})}}
 else if(a==='chat-drawer')openModal({type:'chat'});
 else if(a==='full-chat')go('chat',{chatId:S.issue});
 else if(a==='new-chat')newChat();
 else if(a==='select-chat')go('chat',{chatId:el.dataset.chat});
 else if(a==='prompt'){S.drafts[activeChat().id]=t(el.dataset.prompt+'Text');render();document.getElementById('chat-input')?.focus({preventScroll:true})}
 else if(a==='chat-evidence'){const id=el.dataset.evidence;chooseIssue(el.dataset.issue);S.open[id]=true;S.modal=null;S.scope='all';S.query='';S.filter='all';go('issues',{itab:'evidence'})}
 else if(a==='issue-menu')openModal({type:'menu'});
 else if(a==='note')openModal({type:'note'});
 else if(a==='save-note'){if(!(S.notes[S.issue]||'').trim()){toast(t('reasonRequired'));return}toast(t('noteSaved'))}
 else if(a==='columns')openModal({type:'columns'});
 else if(a==='operation'){const op=el.dataset.op,p=['approve','reject','execute'].includes(op)?selectedPlan():null;if(op==='execute'&&planStatus(p)!=='approved')return;openModal({type:'operation',op,planId:p?.id})}
 else if(a==='confirm-operation')performOperation();
 else if(a==='close-modal')closeModal();
 else if(a==='search'){S.search='';openModal({type:'search'})}
 else if(a==='search-result'){const k=el.dataset.kind,id=el.dataset.id;S.scope='all';S.query='';S.filter='all';if(k==='issues'){chooseIssue(id);go('issues')}else if(k==='resources'){S.resource=id;go('resources',{rview:'detail',rtab:'overview'})}else if(id===change.id){S.kind='change';S.planQuery='';S.risk='all';go('plans',{ptab:'overview'})}else openPlan(PLANS.find(p=>p.id===id).issue)}
 else if(a==='report-mode'){S.reportMode=el.dataset.mode;render()}
 else if(a==='export')exportReport();
 else if(a==='print')window.print();
 else if(a==='share')openModal({type:'share'});
 else if(a==='attach')document.getElementById('chat-file').click();
 else if(a==='send-chat')sendChat();
 else if(a==='remove-file'){const id=activeChat().id,f=S.files[id].find(f=>f.id===el.dataset.id);if(f?.url)URL.revokeObjectURL(f.url);S.files[id]=S.files[id].filter(f=>f.id!==el.dataset.id);render()}
});
document.addEventListener('input',e=>{
 const id=e.target.id;if(id==='issue-query'){S.query=e.target.value;render()}else if(id==='plan-query'){S.planQuery=e.target.value;render()}else if(id==='resource-query'){S.resourceQuery=e.target.value;render()}else if(id==='search-all'){S.search=e.target.value;render()}else if(id==='issue-note'||id==='issue-note-modal')S.notes[S.issue]=e.target.value;else if(id==='operation-reason')S.reason=e.target.value;else if(id==='chat-input'){const cid=activeChat().id;S.drafts[cid]=e.target.value;document.getElementById('send-chat').disabled=!(e.target.value.trim()||S.files[cid]?.length)}
});
document.addEventListener('change',e=>{
 const id=e.target.id;if(id==='global-scope'){if(S.page==='chat'&&!activeChat().issue&&!S.messages[activeChat().id]?.length)activeChat().scope=e.target.value;else S.scope=e.target.value;render()}else if(id==='risk-filter'){S.risk=e.target.value;render()}else if(id==='resource-type'){S.resourceType=e.target.value;render()}else if(id==='version-check')S.checked=e.target.checked;else if(e.target.dataset.column){S.columns[e.target.dataset.column]=e.target.checked;render()}else if(id==='chat-file')addFiles([...e.target.files]);else if(id==='mobile-nav'){const entry=navEntries.find(x=>x[0]===e.target.value);if(entry[1])window.open('http://127.0.0.1:8000'+entry[1],'_blank','noopener');else go(entry[0])}
});
document.addEventListener('toggle',e=>{if(e.target.matches('details[data-open]'))S.open[e.target.dataset.open]=e.target.open;else if(e.target.matches('details[data-nav-group]'))S.navOpen[e.target.dataset.navGroup]=e.target.open},true);
document.addEventListener('keydown',e=>{
 if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openModal({type:'search'})}
 if(e.target.id==='chat-input'&&e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();sendChat()}
});
document.addEventListener('paste',e=>{if(e.target.id==='chat-input'&&e.clipboardData?.files.length){e.preventDefault();addFiles([...e.clipboardData.files])}});
window.addEventListener('popstate',e=>{if(e.state)for(const k of routeFields)if(k in e.state)S[k]=e.state[k];S.modal=null;render()});
window.renderRefinement=render;render();
})();
