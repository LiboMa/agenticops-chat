"""Build an explicitly proposed contract alongside the unchanged live OpenAPI snapshot."""
from pathlib import Path
import copy
import json

ROOT = Path(__file__).resolve().parents[1]
existing = json.loads((ROOT / "api/existing-openapi.json").read_text())
target = copy.deepcopy(existing)
target["info"] = {
    "title": "AgenticOps blue/white workspace — proposed integration contract",
    "version": "2026-10-05.proposed",
    "description": "DESIGN ONLY. Existing operations are retained. x-delivery-status identifies "
                   "proposed extensions and new operations; this document does not claim deployment.",
}
target["servers"] = [{"url": "/", "description": "Same-origin customer deployment"}]
target["x-baseline"] = "existing-openapi.json (live discovery, 2026-10-05)"
schemas = target["components"]["schemas"]
target["components"].setdefault("securitySchemes", {})["BearerAuth"] = {
    "type": "http", "scheme": "bearer",
    "description": "Existing session token/API key. New UI endpoints require an authenticated actor.",
}
changed = []
R = lambda name: {"$ref": "#/components/schemas/" + name}
S = lambda **kw: {"type": "string", **kw}
I = lambda **kw: {"type": "integer", **kw}
B = lambda **kw: {"type": "boolean", **kw}
A = lambda item, **kw: {"type": "array", "items": item, **kw}
N = lambda schema: {"anyOf": [schema, {"type": "null"}]}
def obj(properties, required=(), **kw):
    return {"type": "object", "properties": properties, "required": list(required), **kw}
def dump(path, data):
    (ROOT / path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
def param(name, schema, where="query", required=False, description=""):
    return {"name": name, "in": where, "required": required, "schema": schema, "description": description}
def response(schema, description="Success", media="application/json"):
    return {"description": description, "content": {media: {"schema": schema}}}
def body(schema):
    return {"required": True, "content": {"application/json": {"schema": schema}}}
def extend(path, method, phase, description):
    op = target["paths"][path][method]
    op["x-delivery-status"] = "proposed-extension"
    op["x-phase"] = phase
    op["description"] = (op.get("description", "") + "\n\nPROPOSED: " + description).strip()
    changed.append({"method": method.upper(), "path": path, "status": "extend",
                    "phase": phase, "description": description})
    return op
def new(path, method, name, phase, description, result, request=None, parameters=(), code="200"):
    op = {
        "operationId": name, "summary": description, "description": "PROPOSED, NOT IMPLEMENTED. " + description,
        "tags": ["workspace-ui"], "x-delivery-status": "proposed-new", "x-phase": phase,
        "security": [{"BearerAuth": []}], "parameters": list(parameters),
        "responses": {code: response(result), **{
            s: response(R("UiError"), text) for s, text in {
                "401": "Authentication required", "403": "Action/scope denied",
                "404": "Object not found or not visible", "409": "State or idempotency conflict",
                "422": "Invalid input"}.items()}},
    }
    if request:
        op["requestBody"] = body(request)
    target["paths"].setdefault(path, {})[method] = op
    changed.append({"method": method.upper(), "path": path, "status": "new", "phase": phase,
                    "description": description})
    return op

schemas["UiError"] = obj({
    "detail": S(), "code": S(), "trace_id": N(S()),
}, ["detail", "code"])
schemas["EntityRef"] = obj({
    "entity_type": S(enum=["health_issue", "fix_plan", "change_request", "resource", "report"]),
    "entity_id": I(minimum=1), "content_version": N(I(minimum=1)),
}, ["entity_type", "entity_id"], additionalProperties=False)
schemas["UiAction"] = obj({
    "action": S(), "allowed": B(), "reason_code": N(S()),
    "effect": S(enum=["read", "update", "approve_only", "approve_and_queue_execution",
                     "queue_execution", "request_cancel", "publish"]),
}, ["action", "allowed", "effect"], additionalProperties=False)
schemas["UserPreferences"] = obj({
    "revision": I(minimum=1), "locale": S(enum=["zh", "en"]),
    "home": S(enum=["resume", "chat", "issues", "reports"]),
    "last_route": N(S(maxLength=1000)),
    "nav_groups_open": A(S(enum=["tools", "administration"]), uniqueItems=True),
}, ["revision", "locale", "home", "last_route", "nav_groups_open"])
schemas["PreferencesUpdate"] = obj({
    "locale": S(enum=["zh", "en"]), "home": S(enum=["resume", "chat", "issues", "reports"]),
    "last_route": N(S(maxLength=1000)),
    "nav_groups_open": A(S(enum=["tools", "administration"]), uniqueItems=True),
}, additionalProperties=False, minProperties=1,
    description="Only allow-listed internal read routes. Never store tokens, message text, or action URLs.")
schemas["ChatContext"] = obj({
    "primary": N(R("EntityRef")), "account_id": N(I(minimum=1)),
    "region": N(S(maxLength=80)),
}, ["primary"], additionalProperties=False,
    description="Null primary = independent request. Server resolves object, authorisation and scope. "
                "A linked object's account cannot be overridden by the client.")
schemas["ChatContextResolved"] = obj({
    "primary": N(R("EntityRef")), "account_id": N(I(minimum=1)),
    "region": N(S()), "scope_locked": B(), "resolved_at": S(format="date-time"),
}, ["primary", "account_id", "region", "scope_locked", "resolved_at"])
schemas["UiBootstrap"] = obj({
    "contract_version": S(const="workspace-ui-1"),
    "deployment_id": S(description="Non-secret installation identifier; not a multi-tenant claim."),
    "user_id": I(minimum=1), "locale": S(enum=["zh", "en"]),
    "features": obj({
        "context_chat": B(), "revision_guards": B(), "content_rendering": B(),
        "report_export": B(), "attention": B(), "change_management": B(),
        "chat_replay": B(const=False),
    }, ["context_chat", "revision_guards", "content_rendering", "report_export",
        "attention", "change_management", "chat_replay"]),
    "upload_policy": obj({
        "max_files": I(const=5),
        "image_max_bytes": I(const=5242880), "document_max_bytes": I(const=5242880),
        "text_fallback_max_bytes": I(const=524288),
        "image_extensions": A(S()), "document_extensions": A(S()), "text_extensions": A(S()),
    }, ["max_files", "image_max_bytes", "document_max_bytes", "text_fallback_max_bytes",
        "image_extensions", "document_extensions", "text_extensions"],
       description="Use the file_reader dispatch order: image, native document, then text fallback."),
    "preferences": R("UserPreferences"),
}, ["contract_version", "deployment_id", "user_id", "locale", "features", "upload_policy", "preferences"])
schemas["AttentionItem"] = obj({
    "id": S(), "entity": R("EntityRef"), "reason": S(enum=[
        "approval_required", "clarification_required", "execution_failed", "verification_required"]),
    "title": S(), "account_id": N(I()), "occurred_at": S(format="date-time"),
    "route": S(pattern=r"^/app/"), "available_actions": A(R("UiAction")),
}, ["id", "entity", "reason", "title", "account_id", "occurred_at", "route", "available_actions"])
schemas["AttentionPage"] = obj({
    "items": A(R("AttentionItem")), "total": I(minimum=0), "next_cursor": N(S()),
    "generated_at": S(format="date-time"),
}, ["items", "total", "next_cursor", "generated_at"],
    description="Count and rows use identical actor/account filters and object-level deduplication.")
schemas["RecoveryVerification"] = obj({
    "status": S(enum=["not_run", "pending", "passed", "failed", "inconclusive",
                      "not_applicable", "accepted_manual"]),
    "execution_id": N(I(minimum=1)), "plan_id": N(I(minimum=1)),
    "plan_content_version": N(I(minimum=1)), "reason_code": N(S()),
}, ["status", "execution_id", "plan_id", "plan_content_version", "reason_code"],
    description="Passed requires complete unique check IDs, the same execution/plan version/target, "
                "successful execution and tool evidence. Empty/duplicate/legacy unverifiable results are inconclusive.")
schemas["WorkflowSummary"] = obj({
    "lifecycle": S(enum=["open", "resolved", "dismissed", "unknown"]),
    "investigation": S(enum=["not_started", "running", "complete", "failed", "unknown"]),
    "evidence_status": S(enum=["missing", "partial", "verified", "unknown"]),
    "plan_id": N(I()), "plan_status": N(S()), "execution_id": N(I()), "execution_status": N(S()),
    "verification": R("RecoveryVerification"),
    "as_of": S(format="date-time"),
}, ["lifecycle", "investigation", "evidence_status", "plan_id", "plan_status", "execution_id",
    "execution_status", "verification", "as_of"])
schemas["ContentRendering"] = obj({
    "entity": R("EntityRef"), "source_version": I(minimum=1), "source_hash": S(),
    "language": S(enum=["zh", "en"]),
    "status": S(enum=["ready", "pending", "missing", "failed", "stale"]),
    "fields": {"type": "object", "additionalProperties": S()},
    "body_markdown": N(S()), "protected_value_hash": S(),
    "generated_at": N(S(format="date-time")), "error_code": N(S()),
}, ["entity", "source_version", "source_hash", "language", "status", "fields",
    "body_markdown", "protected_value_hash", "generated_at", "error_code"],
    description="Rendering only: no translation of IDs, commands, evidence refs, check IDs or numeric facts. "
                "The authoritative source revision remains unchanged.")
schemas["TranslationRequest"] = obj({
    "source_version": I(minimum=1),
    "languages": A(S(enum=["zh", "en"]), minItems=1, maxItems=2, uniqueItems=True),
}, ["source_version", "languages"], additionalProperties=False)
schemas["IssueNoteRequest"] = obj({"content": S(minLength=1, maxLength=8000)}, ["content"],
                                additionalProperties=False)
schemas["IssueNote"] = obj({
    "event_id": I(minimum=1), "health_issue_id": I(minimum=1),
    "content": S(), "actor": S(), "created_at": S(format="date-time"),
}, ["event_id", "health_issue_id", "content", "actor", "created_at"])
schemas["ResourcePage"] = obj({"total": I(minimum=0), "items": A(R("ResourceResponse"))}, ["total", "items"])
schemas["IssueTriggerAccepted"] = obj({
    "message": S(), "health_issue_id": I(minimum=1),
}, ["message", "health_issue_id"],
   description="Actual existing 202 body; does not contain a completed RCA or Plan.")
schemas["VerificationCheckDefinition"] = obj({
    "check_id": S(minLength=1, maxLength=100),
    "description": S(), "target_ref": I(minimum=1),
    "pass_condition": S(minLength=1), "required": B(),
}, ["check_id", "description", "target_ref", "pass_condition", "required"],
   additionalProperties=False)
schemas["VerificationCheckResult"] = obj({
    "check_id": S(minLength=1), "execution_id": I(minimum=1),
    "plan_content_version": I(minimum=1), "target_ref": I(minimum=1),
    "outcome": S(enum=["passed", "failed", "inconclusive", "skipped"]),
    "evidence_ref": S(minLength=1), "observed_at": S(format="date-time"),
}, ["check_id", "execution_id", "plan_content_version", "target_ref", "outcome",
    "evidence_ref", "observed_at"], additionalProperties=False,
   description="Read projection of service-validated tool evidence; not an API allowing a caller to assert success.")

new("/api/ui/bootstrap", "get", "getUiBootstrap", "P1",
    "Read authenticated UI capabilities and effective upload policy.", R("UiBootstrap"))
new("/api/users/me/preferences", "get", "getUiPreferences", "P1",
    "Read per-user navigation/locale preferences.", R("UserPreferences"))
pref = new("/api/users/me/preferences", "patch", "updateUiPreferences", "P1",
    "Update allow-listed navigation/locale preferences.", R("UserPreferences"), R("PreferencesUpdate"))
pref["parameters"].append(param("If-Match", S(), "header", True, "ETag from preferences GET."))
pref["responses"]["412"] = response(R("UiError"), "Preferences changed; fetch latest and reconcile.")
target["paths"]["/api/users/me/preferences"]["get"]["responses"]["200"]["headers"] = {
    "ETag": {"schema": S(), "description": "Opaque preference revision."}}
new("/api/ui/attention", "get", "getUiAttention", "P4",
    "Read actionable work for this actor; no model calls or cloud scans.", R("AttentionPage"),
    parameters=[param("account_id", I(minimum=1)), param("limit", I(default=25, minimum=1, maximum=100)),
                param("cursor", S())])
entity_params = [param("entity_type", S(enum=["health_issue", "fix_plan", "change_request", "report"]), "path", True),
                 param("entity_id", I(minimum=1), "path", True)]
new("/api/content/{entity_type}/{entity_id}/rendering", "get", "getContentRendering", "P5",
    "Read a source-version-bound language rendering; GET never invokes a model.", R("ContentRendering"),
    parameters=entity_params + [param("version", I(minimum=1), required=True),
                               param("language", S(enum=["zh", "en"]), required=True)])
new("/api/content/{entity_type}/{entity_id}/translations", "post", "requestContentTranslation", "P5",
    "Ensure language renderings for this source revision; deduplicate by entity/version/language.",
    A(R("ContentRendering")), R("TranslationRequest"), parameters=entity_params, code="202")
new("/api/health-issues/{issue_id}/notes", "post", "appendIssueNote", "P3",
    "Append an attributed note to the existing issue timeline.", R("IssueNote"), R("IssueNoteRequest"),
    parameters=[param("issue_id", I(minimum=1), "path", True)], code="201")
export = new("/api/reports/{report_id}/export", "get", "exportVersionedReport", "P5",
    "Download an already-rendered report revision in one or both languages; no publication.",
    S(format="binary"), parameters=[param("report_id", I(minimum=1), "path", True),
        param("version", I(minimum=1), required=True),
        param("language", S(enum=["zh", "en", "zh-en"]), required=True),
        param("format", S(enum=["html", "pdf", "docx"], default="html"))])
export["responses"]["200"] = {"description": "Pinned report download", "headers": {
    "Content-Disposition": {"schema": S()}, "ETag": {"schema": S()}},
    "content": {m: {"schema": S(format="binary")} for m in [
        "text/html", "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]}}

# Extend existing contracts; preserve method, IDs, list shapes and service ownership.
schemas.setdefault("ChatMessageCreate", obj({
    "content": S(minLength=1, maxLength=10000),
    "scan_focus": N(S(description="Existing comma-separated resource focus.")),
}, ["content"], description="Existing runtime schema absent from live OpenAPI because the handler parses Request manually."))
for name in ["ChatSessionCreate", "ChatSessionUpdate"]:
    schemas[name]["properties"]["context"] = R("ChatContext")
    schemas[name]["properties"]["response_language"] = S(enum=["zh", "en"])
for name in ["ChatSessionResponse", "ChatSessionDetail"]:
    schemas[name]["properties"].update({
        "context": R("ChatContextResolved"), "response_language": S(enum=["zh", "en"]),
        "visibility": S(enum=["private", "workspace"]),
        "owner_user_id": N(I(minimum=1)),
    })
schemas["ChatMessageCreate"]["properties"]["client_message_id"] = S(format="uuid")
schemas["ChatMessageResponse"]["properties"].update({
    "client_message_id": N(S(format="uuid")),
    "dispatch_state": N(S(enum=["accepted", "running", "completed", "failed", "interrupted"])),
})
for method, path in [
    ("post", "/api/chat/sessions"), ("get", "/api/chat/sessions"),
    ("get", "/api/chat/sessions/{session_id}"), ("patch", "/api/chat/sessions/{session_id}"),
    ("delete", "/api/chat/sessions/{session_id}"), ("get", "/api/chat/sessions/{session_id}/messages"),
]:
    extend(path, method, "P2", "Server-validated object context and scope, visibility/ownership checks, "
           "per-session response language. Shared legacy sessions are explicitly classified; no arbitrary owner assignment.")
chat = extend("/api/chat/sessions/{session_id}/messages", "post", "P2",
              "Document existing POST SSE and multipart behavior. Add per-session client_message_id deduplication "
              "and dispatch state. No resumable stream is promised; reconnect reads persisted history.")
chat["requestBody"] = {"required": True, "content": {
    "application/json": {"schema": R("ChatMessageCreate")},
    "multipart/form-data": {"schema": obj({
        "content": S(maxLength=10000), "scan_focus": S(),
        "client_message_id": S(format="uuid"),
        "file": A(S(format="binary"), maxItems=5),
    }, description="At least content or file is required. The repeated multipart field is file, not files."),
    "encoding": {"file": {"style": "form", "explode": True}}},
}}
chat["responses"]["200"] = response(S(), "SSE frames, not JSON", "text/event-stream")
chat["x-sse-events"] = {
    "text": {"status": "existing", "payload": {"token": "string"}},
    "tool_start": {"status": "existing; extend with call_id", "payload": {"name": "string"}},
    "tool_end": {"status": "existing; add explicit outcome, never infer success from name alone", "payload": {"name": "string"}},
    "session_renamed": {"status": "existing", "payload": {"name": "string"}},
    "done": {"status": "existing; add terminal_status and persisted message IDs",
             "payload": {"input_tokens": "integer", "output_tokens": "integer", "suggestions": "string[]"}},
    "error": {"status": "existing; extend with code and trace_id", "payload": {"message": "string"}},
    "accepted": {"status": "proposed-new", "payload": {
        "client_message_id": "uuid", "user_message_id": "integer", "trace_id": "string"}},
}
chat["responses"]["409"] = response(R("UiError"), "Already-dispatched message/session busy; do not start another agent run.")

for name in ["HealthIssueResponse", "FixPlanResponse", "ChangeRequestResponse", "ChangeRequestDetail", "ReportResponse"]:
    schemas[name]["properties"].update({
        "content_version": I(minimum=1),
        "content_hash": S(), "available_actions": A(R("UiAction")),
    })
schemas["HealthIssueResponse"]["properties"].update({
    "workflow_summary": R("WorkflowSummary"),
    "resource_ref": N(I(minimum=1)),
    "anchor_status": S(enum=["anchored", "ambiguous", "account_level", "unanchored"]),
})
schemas["FixPlanResponse"]["properties"].update({
    "scope_hash": S(), "verification": R("RecoveryVerification"),
    "checks_v2": A(R("VerificationCheckDefinition")),
})
schemas["FixExecutionResponse"]["properties"].update({
    "plan_content_version": N(I(minimum=1)), "plan_content_hash": N(S()),
    "verification": R("RecoveryVerification"),
    "check_results_v2": A(R("VerificationCheckResult")),
})
issue_list = extend("/api/health-issues", "get", "P3",
    "Use the canonical HealthIssue representation. Add batched workflow summary and scoped search without per-row requests.")
issue_list["parameters"].append(param("q", S(maxLength=300)))
extend("/api/health-issues/{issue_id}", "put", "P3",
       "Align dismissed with the model state machine; route lifecycle changes through the shared "
       "transition/authorisation service. Content editing must not become a status bypass.")
schemas["HealthIssueUpdate"]["properties"]["status"] = N(S(
    enum=["open", "investigating", "acknowledged", "root_cause_identified", "fix_planned",
          "fix_approved", "fix_executing", "fix_executed", "resolved", "dismissed"]))
for method, path in [
    ("get", "/api/health-issues/{issue_id}"),
    ("get", "/api/health-issues/{issue_id}/timeline"),
    ("get", "/api/fix-plans"), ("get", "/api/fix-plans/{plan_id}"),
    ("get", "/api/changes"), ("get", "/api/changes/{cr_id}"),
    ("get", "/api/fix-executions/{execution_id}"),
]:
    extend(path, method, "P3/P4", "Add validated read metadata, content revision and available actions; "
           "preserve raw lifecycle status and independently describe recovery verification.")
for path in ["/api/fix-plans/{plan_id}", "/api/changes/{cr_id}"]:
    target["paths"][path]["get"]["responses"]["200"]["headers"] = {
        "ETag": {"schema": S(), "description": "Strong opaque aggregate revision including content, scope and lifecycle."}}

guarded = [
    ("put", "/api/fix-plans/{plan_id}"), ("put", "/api/fix-plans/{plan_id}/approve"),
    ("post", "/api/fix-plans/{plan_id}/reject"), ("post", "/api/fix-plans/{plan_id}/execute"),
    ("post", "/api/changes/{cr_id}/approve"), ("post", "/api/changes/{cr_id}/reject"),
    ("post", "/api/changes/{cr_id}/cancel"), ("post", "/api/changes/{cr_id}/clarify"),
    ("post", "/api/changes/{cr_id}/review"), ("post", "/api/changes/{cr_id}/execute"),
    ("post", "/api/changes/{cr_id}/resolve-review"),
]
for method, path in guarded:
    op = extend(path, method, "P4", "Atomic revision/scope/policy check in the shared service. "
                "If-Match is checked in the same transaction as the state transition. Idempotency keys bind "
                "actor, route and canonical body; duplicate requests must not enqueue another execution. "
                "Fix-plan approval may auto-queue execution: show available_actions.effect before confirmation.")
    op.setdefault("parameters", []).extend([
        param("If-Match", S(), "header", True, "Strong ETag of the reviewed plan/change aggregate."),
        param("Idempotency-Key", S(minLength=16, maxLength=200), "header", True, "Application contract, not assumed middleware behavior."),
    ])
    op["responses"].update({
        "412": response(R("UiError"), "Revision changed; refresh and review again."),
        "428": response(R("UiError"), "Required revision precondition missing."),
        "409": response(R("UiError"), "Lifecycle conflict or key reused with a different request."),
    })
    op["x-compatibility"] = "Stage the guard behind the advertised revision_guards capability; migrate old clients before enforcing globally."
resources = extend("/api/resources", "get", "P3", "Document the existing {total,items} response; "
                   "bound pagination. Resource health, inventory lifecycle and observation freshness remain distinct.")
resources["responses"]["200"] = response(R("ResourcePage"))
for path in ["/api/reports", "/api/reports/{report_id}"]:
    op = extend(path, "get", "P5", "Document current ReportResponse shape and expose source revision. "
                "Related-object IDs and account are explicit metadata; never guess a report by title similarity.")
    op["responses"]["200"] = response(A(R("ReportResponse")) if path=="/api/reports" else R("ReportResponse"))
for path in ["/api/reports/generate", "/api/reports/from-session"]:
    extend(path, "post", "P5", "Store a source revision and enqueue paired renderings after source generation. "
           "Align allowed report_type values with the actual generator; locale changes never restart RCA.")
schemas["ReportGenerateRequest"]["properties"]["report_type"] = S(
    enum=["daily", "inventory", "security-review"], default="daily",
    description="Types actually supported by this endpoint. Conversation reports use /from-session.")
pub = extend("/api/reports/{report_id}/publish", "post", "P5",
    "Publish exactly the selected report version and ready language renderings; preserve channel restrictions. "
    "Show destination, format and language before sending; do not substitute generic /api/share for versioned publication.")
schemas["ReportPublishRequest"]["properties"].update({
    "version": I(minimum=1), "language": S(enum=["zh", "en", "zh-en"]),
})
pub.setdefault("parameters", []).append(param("Idempotency-Key", S(minLength=16, maxLength=200), "header", True))
for method in ["get", "post"]:
    callback = extend("/api/im/wecom/callback", method, "P0",
        "Documentation-only repair: give GET and POST distinct operationId values. Preserve callback behavior and authentication.")
    callback["operationId"] = "api_wecom_callback_" + method
    callback["x-documentation-only"] = True
for path in ["/api/health-issues/{issue_id}/rca", "/api/health-issues/{issue_id}/generate-fix-plan"]:
    trigger = extend(path, "post", "P0",
        "Documentation-only repair: actual 202 response is {message,health_issue_id}, "
        "not a completed RCA/Plan. Read the result/timeline endpoints after acceptance.")
    trigger["responses"]["202"] = response(R("IssueTriggerAccepted"), "Accepted for background investigation/generation")
    trigger["x-documentation-only"] = True

# Mark everything retained, including compatibility routes, rather than silently claiming a rewrite.
for path, methods in target["paths"].items():
    for method, op in methods.items():
        if method not in {"get", "post", "put", "patch", "delete"}:
            continue
        op.setdefault("x-delivery-status", "existing-retained")
        if op["x-delivery-status"] != "existing-retained" and not op.get("x-documentation-only"):
            op["security"] = [{"BearerAuth": []}]
target["x-scope-notes"] = [
    "Case is the display name for HealthIssue; no Case table or /api/cases clone.",
    "No generic job platform, new graph database, or API gateway is introduced by this UI plan.",
    "No voice/video upload, attachment replay, durable chat-stream resume or multi-worker session affinity is claimed.",
    "Existing ITSM ServiceNow/Jira bridge is reused; browser code never receives connector credentials.",
]
dump("api/target-openapi.json", target)
delta = copy.deepcopy(target)
delta["paths"] = {}
for c in changed:
    delta["paths"].setdefault(c["path"], {})[c["method"].lower()] = target["paths"][c["path"]][c["method"].lower()]
delta["info"]["title"] += " — changed operations only"
dump("api/proposed-delta.openapi.json", delta)
dump("api/change-register.json", changed)
dump("api/design-tokens.json", {
    "status": "approved design baseline, not applied to product",
    "source": "src/agenticops/web/frontend/src/index.css:11",
    "colors": {"primary": "#2563EB", "primaryHover": "#1D4ED8", "selected": "#EFF6FF",
               "surface": "#FFFFFF", "canvas": "#F8FAFC", "text": "#0F172A",
               "muted": "#64748B", "border": "#E2E8F0"},
    "type": {"latin": "Outfit (self-hosted for customer environments)", "cjk": "PingFang SC / Microsoft YaHei / system sans",
             "body": "14–15px", "label": "12px", "heading": "24px", "lineHeight": 1.7},
    "layout": {"navigation": "200px", "caseQueue": "280–320px", "readingMax": "960px",
               "chatComposerMax": "760px", "detailGutter": "24–32px"},
    "principles": ["First A layout", "White navigation and white reading surface",
                   "Blue for selection/actions, severity colours only for severity",
                   "No KPI dashboard as the mandatory home", "Context chat on demand"],
})
dump("api/state-mapping.json", {
    "status": "proposed read projection; raw backend statuses retained",
    "source": {"issue": "models.py:372", "plan": "models.py:588",
               "change": "models.py:626", "execution": "models.py:690"},
    "issueLifecycle": {"open": ["open", "investigating", "acknowledged", "root_cause_identified",
                               "fix_planned", "fix_approved", "fix_executing", "fix_executed"],
                       "resolved": ["resolved"], "dismissed": ["dismissed"]},
    "plan": ["draft", "pending_approval", "approved", "executing", "executed", "failed", "rejected"],
    "change": ["draft", "under_review", "needs_clarification", "planned", "approved", "executing",
               "needs_review", "completed", "failed", "rolled_back", "rejected", "cancelled"],
    "execution": ["pending", "running", "succeeded", "failed", "rolled_back", "aborted"],
    "verification": ["not_run", "pending", "passed", "failed", "inconclusive", "not_applicable", "accepted_manual"],
    "rules": [
        "Plan approved/executed is not evidence of recovery.",
        "Empty checks never imply passed; legacy unbound checks are inconclusive.",
        "Latest attempt is selected by stable ID/timestamp, never array position or title.",
        "Check evidence binds execution_id + plan_content_version + check_id + target + tool evidence.",
        "All expected checks must be present once and belong to the current successful execution.",
        "Human acceptance uses accepted_manual and must not manufacture machine pass results.",
        "Language changes cannot mutate status, commands, facts, version or approval binding.",
        "Graph unavailable/stale/truncated/ambiguous is explicit, not zero impact or healthy.",
    ],
})
print(json.dumps({"new": sum(c["status"]=="new" for c in changed),
                  "extended": sum(c["status"]=="extend" for c in changed),
                  "target_operations": sum(m in {"get","post","put","patch","delete"} for x in target["paths"].values() for m in x)}, indent=2))
