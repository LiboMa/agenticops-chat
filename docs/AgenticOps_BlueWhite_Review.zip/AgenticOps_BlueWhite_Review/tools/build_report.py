from pathlib import Path
import html
import json
import sys
import markdown
from report_content import SECTIONS

ROOT = Path(__file__).resolve().parents[1]
changes = json.loads((ROOT / "api/change-register.json").read_text())
new_count = sum(x["status"] == "new" for x in changes)
extended_count = sum(x["status"] == "extend" for x in changes)
def current_counts(text):
    return (text.replace("扩展 32 个", f"扩展 {extended_count} 个")
            .replace("32 existing operations", f"{extended_count} existing operations")
            .replace("40 个拟变更操作", f"{len(changes)} 个拟变更操作")
            .replace("40 changed operations", f"{len(changes)} changed operations"))

titles = {
    "design": ("设计基线", "Design baseline", "DESIGN.md"),
    "api": ("API 对接契约", "API integration contract", "API_CONTRACT.md"),
    "plan": ("实施计划", "Implementation plan", "IMPLEMENTATION_PLAN.md"),
}
for group, (zh_title, en_title, filename) in titles.items():
    out = f"# AgenticOps · {zh_title} / {en_title}\n\n2026-10-05 · 设计交付，尚未实施 / Design delivery, not implemented\n\n"
    for g, key, zh, en, zh_body, en_body in SECTIONS:
        if g == group:
            out += f"## {zh} / {en}\n\n### 中文\n\n{current_counts(zh_body).strip()}\n\n### English\n\n{current_counts(en_body).strip()}\n\n"
    if group == "api":
        out += "## 逐项变更登记 / Operation change register\n\n"
        out += "| 状态 / Status | Phase | Method | Path | Contract |\n| --- | --- | --- | --- | --- |\n"
        for c in changes:
            out += f"| {c['status']} | {c['phase']} | {c['method']} | `{c['path']}` | {c['description']} |\n"
        out += "\n## 协议参考 / Protocol references\n\n"
        out += "- OpenAPI 3.1.0: `https://spec.openapis.org/oas/v3.1.0.html`\n"
        out += "- SSE framing: `https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events`\n"
        out += "- If-Match / 412: `https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/If-Match`\n"
    (ROOT / filename).write_text(out)

def bi(zh, en, tag="span", cls=""):
    return f'<{tag} class="{cls}" data-locale="zh">{html.escape(zh)}</{tag}><{tag} class="{cls}" data-locale="en" hidden>{html.escape(en)}</{tag}>'
toc = []
content = []
for group, key, zh, en, zh_body, en_body in SECTIONS:
    toc.append(f'<a href="#{key}">{bi(zh,en)}</a>')
    bodies = []
    for lang, value in [("zh",zh_body),("en",en_body)]:
        rendered = markdown.markdown(current_counts(value), extensions=["tables","fenced_code"])
        rendered = rendered.replace("<table>", '<div class="table-scroll"><table>').replace("</table>", "</table></div>")
        bodies.append(f'<div data-locale="{lang}" {"hidden" if lang=="en" else ""}>{rendered}</div>')
    content.append(f'<section id="{key}" class="report-section"><h2>{bi(zh,en)}</h2>{"".join(bodies)}</section>')
source = json.loads((ROOT / "api/endpoint-catalog.json").read_text())
catalog = [{k: row.get(k) for k in ["method","path","summary","operationId","source","parameters","requestBody","responses"]}
           for row in source if row["scope"]=="api"]
catalog_json = json.dumps(catalog,ensure_ascii=False).replace("</","<\\/")
css = """
:root{--blue:#2563eb;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--soft:#eff6ff}
*{box-sizing:border-box}html{scroll-padding-top:92px}body{margin:0;background:#f8fafc;color:var(--ink);font:14px/1.8 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}
[hidden]{display:none!important}button,input,select{font:inherit}button{cursor:pointer}a{color:#1d4ed8;text-underline-offset:3px}button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #60a5fa;outline-offset:3px}
.report-top{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid var(--line);padding:15px 28px;display:flex;align-items:center;justify-content:space-between;gap:18px}
.wordmark{font-size:19px;font-weight:700;color:#1e40af}.top-actions{display:flex;align-items:center;gap:18px}.top-actions a{font-size:12px}.locale-switch{display:flex;gap:2px;border:1px solid #cbd5e1;border-radius:5px;padding:2px}.locale-switch button{font-size:11px;border:0;background:white;padding:5px 9px;color:#475569;border-radius:3px}.locale-switch button.active{background:var(--soft);color:#1d4ed8}
.report-nav{width:242px;position:fixed;top:71px;bottom:0;overflow:auto;border-right:1px solid var(--line);background:white;padding:25px 16px}.report-nav p{font-size:11px;color:var(--muted);margin:0 10px 12px}.report-nav a{display:block;font-size:12px;padding:7px 10px;color:#475569;text-decoration:none;border-radius:4px}.report-nav a:hover{color:#1d4ed8;background:var(--soft)}
main{margin-left:242px;max-width:1360px;padding:38px 48px 70px}.intro{border-bottom:1px solid #cbd5e1;padding-bottom:27px;margin-bottom:30px}.intro h1{font-size:31px;letter-spacing:-.6px;line-height:1.5;margin:8px 0 10px}.intro p{color:#64748b;max-width:78ch}.date{font-size:11px;color:#64748b}.intro-links{display:flex;gap:11px;flex-wrap:wrap;margin-top:22px}.intro-links a,.small-button{display:inline-flex;align-items:center;border:1px solid #bfdbfe;border-radius:5px;background:white;padding:8px 13px;text-decoration:none;font-size:12px}.intro-links a.primary{background:#2563eb;color:white;border-color:#2563eb}.report-section{background:white;border:1px solid var(--line);padding:29px 32px;margin-bottom:24px;border-radius:6px}.report-section h2{font-size:21px;line-height:1.55;margin:0 0 18px;font-weight:650}.report-section h3{font-size:16px}.report-section p{margin:13px 0;max-width:86ch}.report-section li{margin:7px 0;max-width:85ch}.report-section ul,.report-section ol{padding-left:22px}strong{font-weight:650}
code{font:12px/1.7 ui-monospace,SFMono-Regular,monospace;overflow-wrap:anywhere;background:#f1f5f9;padding:2px 4px;border-radius:3px}pre{background:#f8fafc;border:1px solid var(--line);border-radius:5px;padding:17px;overflow:auto}pre code{background:none;padding:0;white-space:pre}
.table-scroll{overflow:auto;margin:18px 0}table{width:100%;border-collapse:collapse;font-size:12px;line-height:1.75}th{text-align:left;font-size:11px;color:#475569;background:#f8fafc;padding:11px 12px;font-weight:600;border-bottom:1px solid #cbd5e1}td{vertical-align:top;padding:12px;border-bottom:1px solid #e2e8f0}td:first-child{min-width:95px}table code{font-size:11px}.architecture{display:flex;gap:11px;align-items:center;flex-wrap:wrap;margin:24px 0}.architecture div{flex:1;min-width:145px;border:1px solid #bfdbfe;background:#f8fbff;border-radius:5px;padding:15px;font-size:12px;text-align:center}.architecture span.arrow{color:#94a3b8}.architecture small{display:block;color:#64748b}
.catalog-controls{display:flex;gap:10px;flex-wrap:wrap}.catalog-controls input{min-width:0;flex:1;border:1px solid #cbd5e1;padding:8px 11px;border-radius:4px;font-size:12px}.catalog-controls select{border:1px solid #cbd5e1;padding:8px;border-radius:4px;background:white;font-size:12px}.catalog-status{font-size:11px;color:#64748b;margin:12px 0}.endpoint-path{font-size:11px;background:none;white-space:normal}.method{display:inline-block;color:#1d4ed8;font:11px/1.8 ui-monospace,monospace;padding:1px 5px;border-radius:3px;background:#eff6ff}details summary{cursor:pointer;font-size:11px;color:#475569}details pre{font-size:10px;max-width:600px;max-height:350px}.footer{font-size:11px;color:#64748b}.mobile-toc{display:none}
@media(min-width:1600px){main{margin-left:max(242px,calc((100vw - 1270px)/2));max-width:1300px}}
@media(max-width:1100px){.report-nav{width:215px}main{margin-left:215px;padding:28px}.report-section{padding:25px}.intro h1{font-size:27px}}
@media(max-width:800px){.report-nav{display:none}main{margin:0;padding:22px 16px}.report-top{position:relative;padding:13px 16px;flex-wrap:wrap}.wordmark{font-size:17px}.top-actions{gap:10px}.top-actions a{font-size:11px}.intro h1{font-size:25px}.report-section{padding:21px 17px}.report-section h2{font-size:20px}table{min-width:550px}.mobile-toc{display:block;margin-bottom:18px}.mobile-toc select{width:100%;padding:9px;border:1px solid #cbd5e1;border-radius:5px;background:white}.architecture{gap:7px}.architecture div{min-width:120px;padding:12px}.catalog-controls input{flex-basis:100%}.catalog-table{min-width:700px}.report-top .top-actions{flex-wrap:wrap}.report-section p{font-size:13px}}
@media print{@page{size:A4;margin:17mm}.report-top,.report-nav,.mobile-toc,.intro-links,.catalog-controls,.small-button{display:none!important}main{margin:0;padding:0;max-width:none}.report-section{border:0;padding:0;margin-bottom:26px;break-before:page}.report-section h2{break-after:avoid}.intro h1{font-size:25px}table{min-width:0!important;font-size:9pt}tr{break-inside:avoid}pre{white-space:pre-wrap}body{font-size:10pt;background:white}.table-scroll{overflow:visible}}
"""
document = f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AgenticOps · 蓝白版设计、API 与实施计划</title><style>{css}</style></head><body>
<header class="report-top"><div class="wordmark">AgenticOps</div><div class="top-actions"><a data-preview href="ui-refinement.html?lang=zh">{bi('打开蓝白版范本','Open blue/white prototype')}</a><div class="locale-switch" aria-label="Language / 语言"><button data-lang="zh">中文</button><button data-lang="en">English</button></div></div></header>
<aside class="report-nav"><p>{bi('设计与对接基线 · 2026-10-05','Design and integration baseline · 2026-10-05')}</p>{''.join(toc)}<a href="#catalog">{bi('完整 API 目录','Complete API catalog')}</a></aside>
<main><div class="mobile-toc"><select id="mobile-toc" aria-label="Sections"><option value="" data-zh="目录" data-en="Contents">目录</option>{''.join(f'<option value="{k}" data-zh="{html.escape(zh)}" data-en="{html.escape(en)}">{html.escape(zh)}</option>' for g,k,zh,en,z,e in SECTIONS)}<option value="catalog">API</option></select></div>
<div class="intro"><div class="date">2026-10-05 · {bi('设计已确认 · 接口待实施','Design direction confirmed · Integration pending')}</div><h1>{bi('蓝白界面，沿用第一版工作方式','Blue and white, built on design A')}</h1><p>{bi('以对话发起需求，以事件接手处理，以报告交付结果。现有接口优先，逐阶段完成前端改造与对接。','Start requests in Chat, take action in Cases, and deliver results through Reports. Reuse existing APIs and integrate the frontend in reviewable phases.')}</p>
<div class="intro-links"><a class="primary" data-preview href="ui-refinement.html?lang=zh">{bi('体验最终方向','Try the chosen direction')}</a><a href="api/target-openapi.json" download>{bi('整体目标 OpenAPI','Full target OpenAPI')}</a><a href="IMPLEMENTATION_PLAN.md" download>{bi('实施 Plan','Implementation plan')}</a><a href="AgenticOps_BlueWhite_Review.zip" download>{bi('完整审阅包','Complete review package')}</a></div>
<div class="architecture"><div>Chat / Cases / Reports<small>{bi('用户的工作入口','User workspace')}</small></div><span class="arrow" aria-hidden="true">→</span><div>React · Query · SSE<small>{bi('复用现有前端基础','Retain frontend foundations')}</small></div><span class="arrow" aria-hidden="true">→</span><div>FastAPI · Services<small>{bi('现有接口 + 增量契约','Existing APIs + contract additions')}</small></div><span class="arrow" aria-hidden="true">→</span><div>Agents · Inventory · ITSM<small>{bi('现有执行与数据能力','Existing execution and data')}</small></div></div></div>
{''.join(content)}
<section class="report-section" id="catalog"><h2>{bi('完整现有 API 目录','Complete existing API catalog')}</h2><p>{bi('231 个现有 API 操作。可搜索路径、方法或函数；展开可查看参数、请求体、返回模型及源码位置。此表是现有快照，拟新增内容在目标合同中单独标记。','231 existing API operations. Search path, method or function; expand for parameters, body, responses and source. This table is the current snapshot; proposed additions are separately marked in the target contract.')}</p><div class="catalog-controls"><input id="api-search" type="search" aria-label="Search APIs" placeholder="/api/chat · approve · GET"><select id="api-method" aria-label="HTTP method"><option value="">All methods</option>{''.join(f'<option>{x}</option>' for x in ['GET','POST','PUT','PATCH','DELETE'])}</select></div><div id="catalog-status" class="catalog-status"></div><div class="table-scroll"><table class="catalog-table"><thead><tr><th>Method</th><th>Path</th><th>{bi('操作与契约','Operation and contract')}</th></tr></thead><tbody id="catalog-body"></tbody></table></div><button class="small-button" id="show-more">{bi('显示更多','Show more')}</button></section>
<p class="footer">{bi('本报告与范本为设计交付。新增接口尚未部署，示例操作不调用云或外部消息渠道。','This is a design delivery. Proposed APIs are not deployed; sample actions do not call cloud or external messaging services.')}</p></main>
<script id="api-data" type="application/json">{catalog_json}</script>
<script>
const rows=JSON.parse(document.getElementById('api-data').textContent);let visibleLimit=40,lang=new URLSearchParams(location.search).get('lang')==='en'?'en':'zh';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));
function drawCatalog(){{const q=document.getElementById('api-search').value.toLowerCase(),method=document.getElementById('api-method').value;const matched=rows.filter(r=>(!method||r.method===method)&&(r.method+' '+r.path+' '+r.operationId+' '+r.summary).toLowerCase().includes(q));document.getElementById('catalog-status').textContent=(lang==='zh'?'已显示 ':'Showing ')+Math.min(visibleLimit,matched.length)+' / '+matched.length;document.getElementById('catalog-body').innerHTML=matched.slice(0,visibleLimit).map(r=>`<tr><td><span class="method">${{r.method}}</span></td><td><code class="endpoint-path">${{esc(r.path)}}</code></td><td>${{esc(r.summary)}}<details><summary>${{lang==='zh'?'参数、返回与源码':'Parameters, responses and source'}}</summary><pre>${{esc(JSON.stringify({{operationId:r.operationId,source:r.source,parameters:r.parameters,requestBody:r.requestBody,responses:r.responses}},null,2))}}</pre></details></td></tr>`).join('');document.getElementById('show-more').hidden=matched.length<=visibleLimit;}}
function renderLocale(){{document.documentElement.lang=lang==='zh'?'zh-CN':'en';document.title=lang==='zh'?'AgenticOps · 蓝白版设计、API 与实施计划':'AgenticOps · Blue/white design, API and implementation';document.querySelectorAll('[data-locale]').forEach(e=>e.hidden=e.dataset.locale!==lang);document.querySelectorAll('[data-lang]').forEach(e=>{{e.classList.toggle('active',e.dataset.lang===lang);e.setAttribute('aria-pressed',String(e.dataset.lang===lang))}});document.querySelectorAll('#mobile-toc [data-zh]').forEach(e=>e.textContent=e.dataset[lang]);document.querySelectorAll('[data-preview]').forEach(e=>e.href='ui-refinement.html?lang='+lang);document.getElementById('api-method').options[0].textContent=lang==='zh'?'全部方法':'All methods';drawCatalog();history.replaceState(null,'','?lang='+lang+location.hash)}}
document.querySelectorAll('[data-lang]').forEach(e=>e.onclick=()=>{{lang=e.dataset.lang;renderLocale()}});document.getElementById('api-search').oninput=()=>{{visibleLimit=40;drawCatalog()}};document.getElementById('api-method').onchange=()=>{{visibleLimit=40;drawCatalog()}};document.getElementById('show-more').onclick=()=>{{visibleLimit+=40;drawCatalog()}};document.getElementById('mobile-toc').onchange=e=>{{if(e.target.value)location.hash=e.target.value}};renderLocale();
</script></body></html>"""
(ROOT / "implementation-review.html").write_text(document)
(ROOT / "README.md").write_text(f"""# AgenticOps · 蓝白版审阅与实施交接 / Blue-white design and implementation handoff

2026-10-05

打开 `implementation-review.html` 阅读可切换中英文的完整报告；打开 `ui-refinement.html` 体验蓝白版。
Open `implementation-review.html` for the bilingual report, or `ui-refinement.html` for the prototype.

当前 API：231 个操作；拟新增 {new_count} 个，扩展 {extended_count} 个。
Existing API: 231 operations; {new_count} proposed additions and {extended_count} extensions.

所有 target / delta 契约均为待实施设计。范本只保存本地偏好和样例状态，没有调用真实业务 API。
Target/delta contracts are proposed. The prototype stores local preferences/sample state and calls no business API.

文件 / Files:

- DESIGN.md: 设计基线 / design baseline
- API_CONTRACT.md: API mapping, gaps, payloads, streaming, revision and language rules
- IMPLEMENTATION_PLAN.md: phased tasks, dependencies, acceptance and rollback
- api/existing-openapi.json: untouched live snapshot
- api/endpoint-catalog.json: complete existing inventory with source locations
- api/target-openapi.json: full proposed target
- api/proposed-delta.openapi.json: changed operations only
- api/change-register.json: {len(changes)} proposed changes
- api/state-mapping.json, api/design-tokens.json: implementation inputs
- qa/: design-artifact verification; not production API tests

可通过静态服务或直接打开 HTML 使用。复制时保留 assets/api 文件夹。
Use a static server or open the HTML directly. Keep the assets/api folders.

```sh
python3 -m http.server 8875 --bind 127.0.0.1 --directory {ROOT}
```

后续从 P0/P1 开始，不直接全量替换生产前端。
Start subsequent implementation at P0/P1, not a full production frontend replacement.
""")
print(json.dumps({"sections":len(SECTIONS),"api_operations":len(catalog),"changed_operations":len(changes),
                  "html_bytes":len(document.encode())}))
