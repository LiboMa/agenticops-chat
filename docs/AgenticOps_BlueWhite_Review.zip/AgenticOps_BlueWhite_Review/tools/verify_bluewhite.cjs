const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('/Users/malibo/.npm/_npx/9833c18b2d85bc59/node_modules/playwright-core');
const root=path.resolve(__dirname,'..'),origin='http://127.0.0.1:8875',base=origin+'/ui-refinement.html';
const result={checks:[],errors:[],requests:[],responsive:[]};
function check(name,ok,detail){result.checks.push({name,passed:!!ok,...(detail?{detail}:{})});if(!ok)throw Error(name)}
(async()=>{
 const b=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 try{
  const p=await b.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
  p.on('pageerror',e=>result.errors.push(e.message));p.on('request',r=>result.requests.push({url:r.url(),method:r.method()}));
  await p.goto(base);
  check('First visit starts in independent Chat',await p.evaluate(()=>refinementState.page==='chat'&&refinementState.chatId==='request-1'));
  check('Blue action token and white navigation',await p.evaluate(()=>getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()==='#2563eb'&&getComputedStyle(document.querySelector('.nav')).backgroundColor==='rgb(255, 255, 255)'));
  await p.locator('.nav-primary [data-page="issues"]').click();await p.locator('.queue [data-issue="I-2403"]').click();
  await p.goto(base);
  check('Bare entry restores last case and page',await p.evaluate(()=>refinementState.page==='issues'&&refinementState.issue==='I-2403'));
  await p.locator('[data-a="preferences"]').click();await p.locator('#home-choice').selectOption('reports');await p.locator('[data-a="save-preferences"]').click();
  await p.goto(base);
  check('Pinned home opens Reports',await p.evaluate(()=>refinementState.page==='reports'));
  await p.goto(base+'?page=plans&issue=I-2401');
  check('Explicit deep link overrides home preference',await p.evaluate(()=>refinementState.page==='plans'&&refinementState.issue==='I-2401'));
  await p.locator('[data-a="attention"]').click();
  check('Attention contains specific actionable records',await p.locator('.attention-item').count()===4);
  await p.locator('[data-a="attention-change"]').click();
  check('Attention opens the Change plan',await p.evaluate(()=>refinementState.kind==='change'&&refinementState.page==='plans'));
  await p.locator('[data-a="preferences"]').click();await p.locator('#home-choice').selectOption('resume');await p.locator('[data-a="save-preferences"]').click();
  await p.goto(base+'?page=chat&chat=request-1&lang=zh');
  await p.locator('#chat-input').fill('保留草稿：检查订单服务');
  const attachments=Array.from({length:6},(_,i)=>({name:`evidence-${i}.log`,mimeType:'text/plain',buffer:Buffer.from('sample')}));
  await p.locator('#chat-file').setInputFiles(attachments);
  check('Prototype caps attachments at five',await p.locator('.chat-composer .attachment').count()===5);
  await p.locator('[data-a="lang"][data-lang="en"]').click();
  check('Locale preserves draft/files',await p.locator('#chat-input').inputValue()==='保留草稿：检查订单服务'&&await p.locator('.chat-composer .attachment').count()===5);
  await p.locator('.nav-primary [data-page="issues"]').click();await p.locator('[data-a="chat-drawer"]').click();
  check('Case context does not inherit independent draft',await p.locator('#chat-input').inputValue()==='');
  await p.keyboard.press('Escape');await p.locator('.nav-primary [data-page="chat"]').click();
  check('Navigation preserves the independent draft',await p.locator('#chat-input').inputValue()==='保留草稿：检查订单服务');
  for(const lang of ['zh','en']){
   for(const page of ['chat','issues','plans','resources','reports']){
    await p.goto(base+`?page=${page}&lang=${lang}&chat=request-1&issue=I-2401`);
    check(`Page ${page}/${lang} renders`,await p.locator('h1').count()>0);
    await p.screenshot({path:`${root}/screenshots/bluewhite-${page}-${lang}.png`,fullPage:true});
   }
   await p.goto(origin+'/implementation-review.html?lang='+lang);
   check('Report locale '+lang,await p.locator('#decision [data-locale="'+lang+'"]').last().isVisible());
   await p.locator('#api-search').fill('/api/chat/sessions');
   check('Searchable API catalog '+lang,await p.locator('#catalog-body tr').count()===7);
   await p.locator('#api-method').selectOption('POST');
   check('Catalog HTTP method filter '+lang,await p.locator('#catalog-body tr').count()===2);
   await p.locator('#api-search').fill('');await p.locator('#api-method').selectOption('');
   await p.screenshot({path:`${root}/screenshots/implementation-review-${lang}.png`,fullPage:false});
   const download=p.waitForEvent('download');await p.locator('.intro-links a[href="api/target-openapi.json"]').click();const dl=await download;check('Target contract downloadable '+lang,(await dl.suggestedFilename()).includes('json'));
  }
  for(const width of [1600,1280,768,390,320]){
   await p.setViewportSize({width,height:900});
   for(const file of ['ui-refinement.html?page=chat&lang=en&chat=request-1','ui-refinement.html?page=issues&lang=zh','ui-refinement.html?page=reports&lang=en','implementation-review.html?lang=en']){
    await p.goto(origin+'/'+file);const dims=await p.evaluate(()=>({width:innerWidth,document:document.documentElement.scrollWidth}));result.responsive.push({file,...dims});check(file+' fits '+width,dims.document<=width,dims);
    if(width===390)await p.screenshot({path:`${root}/screenshots/${file.startsWith('implementation')?'report-mobile-en':file.includes('page=chat')?'bluewhite-chat-mobile-en':file.includes('page=issues')?'bluewhite-cases-mobile-zh':'bluewhite-reports-mobile-en'}.png`,fullPage:file.startsWith('ui')});
   }
  }
  await p.goto('file://'+root+'/implementation-review.html?lang=en');check('Offline report works',await p.locator('#catalog-body tr').count()===40);
  await p.goto('file://'+root+'/ui-refinement.html?page=chat');check('Offline prototype works',await p.locator('#chat-input').isVisible());
  check('No JavaScript errors',result.errors.length===0,result.errors);
  check('No business API calls',result.requests.every(r=>r.method==='GET'&&(r.url.startsWith(origin+'/')||r.url.startsWith('blob:')||r.url.startsWith('file://'+root+'/'))));
  result.passed=true;
 }catch(e){result.passed=false;result.failure=e.stack;console.error(e.stack)}
 finally{result.completedAt=new Date().toISOString();fs.writeFileSync(root+'/qa/browser-verification.json',JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,checks:result.checks.length,errors:result.errors,failure:result.failure},null,2));await b.close();if(!result.passed)process.exitCode=1}
})();
