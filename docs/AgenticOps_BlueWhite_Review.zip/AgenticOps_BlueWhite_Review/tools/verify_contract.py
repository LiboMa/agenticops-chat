from pathlib import Path
import json
import re
from jsonschema import Draft202012Validator, RefResolver

ROOT = Path(__file__).resolve().parents[1]
report = {"checks": [], "scope": "Design contract structure and examples only; no live business calls."}
def check(name, result):
    report["checks"].append({"name": name, "passed": bool(result)})
    if not result:
        raise AssertionError(name)
def walk(value):
    if isinstance(value, dict):
        yield value
        for v in value.values():
            yield from walk(v)
    elif isinstance(value, list):
        for v in value:
            yield from walk(v)
def resolve(doc, ref):
    current = doc
    assert ref.startswith("#/")
    for part in ref[2:].split("/"):
        current = current[part.replace("~1", "/").replace("~0", "~")]
    return current
try:
    baseline = json.loads((ROOT / "api/existing-openapi.json").read_text())
    target = json.loads((ROOT / "api/target-openapi.json").read_text())
    register = json.loads((ROOT / "api/change-register.json").read_text())
    for filename in ["existing-openapi.json", "target-openapi.json", "proposed-delta.openapi.json"]:
        doc = json.loads((ROOT / "api" / filename).read_text())
        refs = [o["$ref"] for o in walk(doc) if "$ref" in o]
        for ref in refs:
            resolve(doc, ref)
        check(f"{filename}: {len(refs)} internal references resolve", True)
        ids = []
        for path, methods in doc["paths"].items():
            required = set(re.findall(r"{([^}]+)}", path))
            for method, op in methods.items():
                if method not in {"get", "post", "put", "patch", "delete"}:
                    continue
                ids.append(op["operationId"])
                params = methods.get("parameters", []) + op.get("parameters", [])
                supplied = {p["name"] for p in params if p.get("in") == "path" and p.get("required")}
                assert required <= supplied, (path, required, supplied)
        if filename == "existing-openapi.json":
            duplicates = sorted({x for x in ids if ids.count(x)>1})
            report["baseline_findings"] = {"duplicate_operation_ids": duplicates}
            check("Unchanged baseline preserves the documented WeCom operationId collision",
                  len(duplicates)==1 and "wecom" in duplicates[0])
        else:
            check(f"{filename}: unique operation IDs and declared path parameters", len(ids) == len(set(ids)))
    for path, methods in baseline["paths"].items():
        check(f"Retained route {path}", all(m in target["paths"][path] for m in methods))
    check("Exactly eight new operations", sum(c["status"] == "new" for c in register) == 8)
    check("37 explicit extensions, including four documentation-only repairs", sum(c["status"] == "extend" for c in register) == 37)
    schemas = target["components"]["schemas"]
    for name, schema in schemas.items():
        Draft202012Validator.check_schema(schema)
    check(f"{len(schemas)} schemas structurally valid under JSON Schema 2020-12", True)
    resolver = RefResolver.from_schema(target)
    samples = {
        "ChatContext": {"primary": None, "account_id": 3, "region": "ap-southeast-1"},
        "UserPreferences": {"revision": 1, "locale": "zh", "home": "resume",
                            "last_route": "/app/issues/42", "nav_groups_open": ["tools"]},
        "IssueNoteRequest": {"content": "Database lock evidence is still missing."},
        "TranslationRequest": {"source_version": 2, "languages": ["zh", "en"]},
        "VerificationCheckResult": {"check_id": "svc-health", "execution_id": 12,
            "plan_content_version": 3, "target_ref": 27, "outcome": "passed",
            "evidence_ref": "tool-result:84", "observed_at": "2026-10-05T03:00:00Z"},
    }
    for name, sample in samples.items():
        validator = Draft202012Validator(schemas[name], resolver=resolver)
        check(name + ": positive example", validator.is_valid(sample))
    check("Unknown context properties rejected",
          not Draft202012Validator(schemas["ChatContext"], resolver=resolver).is_valid({"primary": None, "approved_by": "admin"}))
    check("Blank note rejected", not Draft202012Validator(schemas["IssueNoteRequest"]).is_valid({"content": ""}))
    check("Unsupported language rejected", not Draft202012Validator(schemas["TranslationRequest"]).is_valid({"source_version": 2, "languages": ["fr"]}))
    check("SSE declared as text/event-stream", "text/event-stream" in target["paths"]["/api/chat/sessions/{session_id}/messages"]["post"]["responses"]["200"]["content"])
    check("Repeated file field documented", "file" in target["paths"]["/api/chat/sessions/{session_id}/messages"]["post"]["requestBody"]["content"]["multipart/form-data"]["schema"]["properties"])
    check("Resource list shape typed", target["paths"]["/api/resources"]["get"]["responses"]["200"]["content"]["application/json"]["schema"]["$ref"].endswith("ResourcePage"))
    check("Fix approval retains PUT", "put" in target["paths"]["/api/fix-plans/{plan_id}/approve"] and "post" not in target["paths"]["/api/fix-plans/{plan_id}/approve"])
    for name in ["DESIGN.md", "API_CONTRACT.md", "IMPLEMENTATION_PLAN.md"]:
        text = (ROOT / name).read_text()
        check(name + ": bilingual", "### 中文" in text and "### English" in text)
        check(name + ": no unresolved placeholders", not re.search(r"\b(TODO|TBD|FIXME)\b", text))
    report["passed"] = True
except Exception as exc:
    report["passed"] = False
    report["failure"] = repr(exc)
(ROOT / "qa/contract-verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"passed":report["passed"],"checks":len(report["checks"]),"failure":report.get("failure")}))
if not report["passed"]:
    raise SystemExit(1)
