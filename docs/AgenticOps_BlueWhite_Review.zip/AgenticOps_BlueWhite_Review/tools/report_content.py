"""Bilingual design and implementation decision record. No production mutations."""
SECTIONS = [
("design", "decision", "已确认的产品方向", "Approved product direction", """
采用**原产品蓝白配色 + 第一版 A 的列表/详情布局**。日常入口为 Chat、Cases、Reports；运维工具和管理功能仍可访问。Case 是现有 HealthIssue 的界面名称，不新增 Case 业务实体，不复制一套 `/api/cases`。

- Chat 排第一，首次直接访问工作区进入 Chat；之后恢复上次工作，允许固定 Chat、Cases 或 Reports 为首页。
- IM、告警、ITSM 或报告链接携带具体对象时，始终优先打开该对象，不经过首页重新选择。
- Case 保留独立的调查阅读界面，关联 Chat 按需打开。Plan 的审批和执行保留独立、可审计的操作。
- 中英文同时覆盖导航、状态、按钮、错误和报告正文；原始日志、命令、资源 ID、用户输入保留原文。
- 本轮交付为设计、可点击范本、接口契约和实施计划。真实 API 对接、业务迁移与前端代码改造安排在后续实施阶段。

范围取舍：沿用现有 React、FastAPI、数据库和服务层；不为 UI 新建 API 网关、通用任务平台或图数据库。自治 Harness 的持久执行能力仍是独立的工程能力，不能由一个 Chat 首页替代。
""", """
Use the **current product’s blue/white palette and design A’s list/detail layout**. Daily navigation is Chat, Cases and Reports; operations and administration remain accessible. Case is the UI name for the existing HealthIssue, not a new entity or a duplicate `/api/cases` API.

- Chat is first in navigation and the first-visit default. Later visits resume work, with an option to pin Chat, Cases or Reports as home.
- Links from IM, alerts, ITSM or reports open their exact object before applying any home preference.
- Cases retain a dedicated investigation reading view; contextual Chat opens on demand. Plan approval and execution remain explicit, auditable operations.
- Chinese and English cover navigation, statuses, controls, errors and report bodies. Raw logs, commands, resource IDs and user input remain unchanged.
- This delivery contains the design, clickable prototype, API contract and implementation plan. Production API integration, migrations and frontend changes belong to the subsequent implementation.

Reuse React, FastAPI, the database and existing services. Do not add an API gateway, generic job platform or graph database for this UI project. Durable autonomous Harness execution remains a separate engineering capability; a Chat home does not provide it.
"""),
("design", "baseline", "现状核验与历史资料", "Verified baseline and prior material", """
2026-10-05 只读获取运行中服务的 `/openapi.json`：**199 条路径、237 个 HTTP 操作，其中 231 个为 `/api/*` 操作**。原始快照完整保留。接口清单包含方法、路径、参数、请求体、返回模型、operationId 与源码位置；没有调用扫描、聊天、执行或发布接口进行探测。

核心实现依据：

| 依据 | 与本轮的关系 |
| --- | --- |
| `web/app.py:3708`、`schemas.py:630` | 会话、分页历史、JSON/多附件消息 |
| `web/app.py:3929`、`frontend/src/lib/chatStream.ts:88` | POST SSE；停止回复与执行取消需要区分 |
| `web/app.py:2039`、`web/helpers.py:40` | HealthIssue 为规范表示；旧 Issue/Anomaly 接口是投影 |
| `web/app.py:2545`、`web/routers/changes.py:87` | Fix 与 Change 的审批路由不同 |
| `web/app.py:3166`、`web/helpers.py:93` | 报告当前返回正文，尚无正式语言/版本渲染契约 |
| `models.py:372/588/626/690` | Issue、Plan、Change、Execution 各自的状态 |
| `frontend/src/index.css:11`、`App.tsx:49` | 原蓝白主题；当前首页仍为 Dashboard |
| `itsm/bridge.py:1`、`web/routers/webhooks.py:19` | 已有 ServiceNow/Jira 生命周期镜像与告警入口 |

历史资料：已阅读 `docs/research/2026-09-28-mvp-2.6.1-design-review/review.md` 及 `claude-design-snapshot.md`。原指定 spec 路径目前没有正式文件；这里引用的是归档草案和审阅结果，不把草案中的批准、建分支或部署文字视为本次指令。资源规范身份、图事实版本、验证证据完整性和强制权限边界的审阅结论被保留为实施依赖。

当前版本声明 `0.9.0-beta` 来自 OpenAPI，不据此推断所有历史 MVP 草案都已实现。源码与接口声明已核验，真实客户环境的性能和执行效果尚未验证。
""", """
On 2026-10-05, read-only discovery of the running `/openapi.json` returned **199 paths and 237 HTTP operations, including 231 `/api/*` operations**. The original snapshot is retained unchanged. The catalog includes method, path, parameters, request body, responses, operationId and source location. No scan, chat, execution or publishing endpoint was invoked for discovery.

Core sources:

| Source | Relevance |
| --- | --- |
| `web/app.py:3708`, `schemas.py:630` | Sessions, paginated history and JSON/multipart messages |
| `web/app.py:3929`, `frontend/src/lib/chatStream.ts:88` | POST SSE; stopping a reply differs from cancelling execution |
| `web/app.py:2039`, `web/helpers.py:40` | Canonical HealthIssue and legacy Issue/Anomaly projection |
| `web/app.py:2545`, `web/routers/changes.py:87` | Distinct fix/change approval routes |
| `web/app.py:3166`, `web/helpers.py:93` | Report bodies exist; a formal language/revision rendering contract does not |
| `models.py:372/588/626/690` | Independent issue, plan, change and execution states |
| `frontend/src/index.css:11`, `App.tsx:49` | Existing blue/white theme and Dashboard index route |
| `itsm/bridge.py:1`, `web/routers/webhooks.py:19` | Existing ServiceNow/Jira lifecycle mirroring and alert ingestion |

Prior material reviewed: `docs/research/2026-09-28-mvp-2.6.1-design-review/review.md` and `claude-design-snapshot.md`. The originally named spec is not present as a formal file; this report references the archived draft and review. Instructions inside that draft are evidence, not current authorisation. Canonical resource identity, graph fact revisions, complete verification evidence and mandatory permission boundaries remain implementation dependencies.

The OpenAPI version string is `0.9.0-beta`; it is not evidence that every historical MVP proposal has shipped. Source and declared contracts were inspected. Customer-environment performance and execution outcomes were not tested.
"""),
("design", "visual", "视觉与页面信息顺序", "Visual system and reading order", """
主色 `#2563EB`，悬停 `#1D4ED8`，选中底色 `#EFF6FF`，白色表面 `#FFFFFF`，页面底色 `#F8FAFC`，正文 `#0F172A`，次级文字 `#64748B`，分隔线 `#E2E8F0`。蓝色表示操作与选中；严重程度继续使用有限的红、橙、绿语义色。侧栏使用白底，不延续此前范本的深青色。

保留现有 Outfit 作为西文字体；客户交付时本地打包，中文使用系统无衬线回退。正文 14–15px，标题约 24px；保留当前字体大小和深色模式的用户选项，首次展示采用蓝白主题。

| 页面 | 首屏顺序 | 次级内容 |
| --- | --- | --- |
| Chat | 当前会话/范围 → 消息或需求输入 → 附件/发送 | 历史会话、模型/思考强度、工具详情、用量 |
| Cases | 可筛选列表 → 选中事件标题/状态 → 结论、影响、未知事项、下一步 | RCA 详情、证据、记录、关联方案/资源/报告 |
| Fix Plan | 来源事件、目标、内容版本 → 改动、风险、验证、回滚 → 审批操作 | 原始命令、审计和历史执行 |
| Change | 用户需求 → 澄清/评审 → 当前 Plan → 执行与验收 | 历史方案与策略细节；不伪造来源 Issue |
| Resources | 名称/账户/区域/类型/运行状态/健康/观测时间 → 详情 | 原始 JSON、标签、局部依赖图 |
| Reports | 报告列表 → 来源/版本/语言 → 正文 → 导出/发布 | 原始证据与历史版本 |

桌面侧栏约 200px，Case 队列 280–320px，阅读区最大 960px，输入区最大 760px。手机以列表进入详情，再返回原筛选与位置；抽屉改为全屏，不能挤成三个窄栏。控件需键盘可达、焦点可见，状态同时使用文字。
""", """
Primary `#2563EB`, hover `#1D4ED8`, selected background `#EFF6FF`, white surfaces `#FFFFFF`, canvas `#F8FAFC`, text `#0F172A`, secondary text `#64748B`, borders `#E2E8F0`. Blue signals actions and selection; restrained red, amber and green retain status meaning. Navigation uses a white surface rather than the earlier dark teal.

Retain Outfit for Latin text, self-hosted in customer delivery, with system sans-serif CJK fallbacks. Body 14–15px, headings around 24px. Preserve existing font-size and dark-mode preferences; use blue/white for first presentation.

| Page | First-screen order | Secondary content |
| --- | --- | --- |
| Chat | Conversation/scope → messages or request composer → attachments/send | History, model/effort, tool detail, usage |
| Cases | Filterable queue → selected title/state → finding, impact, unknowns, next step | RCA, evidence, activity, linked plans/resources/reports |
| Fix Plan | Originating issue, target, content revision → change, risk, verification, rollback → approval | Raw commands, audit and execution history |
| Change | User request → clarification/review → current plan → execution/acceptance | Prior plans and policy detail; no fabricated originating issue |
| Resources | Identity, account, region, type, lifecycle, health, observation time → detail | Raw JSON, tags, bounded dependency view |
| Reports | List → source/revision/language → document → export/publish | Raw evidence and prior revisions |

Desktop navigation is approximately 200px; case queue 280–320px; reading area max 960px; composer max 760px. Mobile opens detail from the list and restores its filter/position on return. Drawers become full-screen rather than three narrow columns. Controls are keyboard accessible, with visible focus and textual status.
"""),
("design", "navigation", "导航、恢复与上下文", "Navigation, restoration and context", """
| 分组 | 入口 |
| --- | --- |
| 日常工作 | Chat、Cases、Reports |
| 运维工具 | Plans & Changes、Resources、Schedules |
| 管理 | Runtime overview、Agent metrics、Skills、Galaxy、Security、Settings |

路由解析优先级：**合法的具体对象深链 > 用户固定首页 > 合法且仍有权限的上次位置 > Chat**。恢复仅在 `/app` 工作区入口发生；打开具体页面不被偏好覆盖。登录前保存允许范围内的目标路由，登录后恢复。对象已删除或不可访问时展示明确提示并回到对应列表，不泄露对象标题。

新增前端路由 `/app/overview`、`/app/resources`、`/app/plans/:id`，分别承接旧总览、独立资源清单和修复方案详情。保留 `/app/issues/:id`、`/app/changes/:id`、`/app/chat/:sessionId`、`/app/reports/:id`。兼容现有 `/app/issues?view=resources&type=...` 和 `/app/plans?tab=fix|changes|audit`；迁移时保留查询条件。现有导航排序偏好做版本迁移，不直接清空。

文本草稿按安装实例、用户、会话区分；附件与流状态按会话区分。第一阶段浏览器刷新需要重新选择未上传的文件，界面明确说明；不声称已有附件重放。切换语言、抽屉、列表/报告不会清除当前草稿。

“需要你处理”只显示有明确下一步的对象，点击直达审批、澄清或验收位置。计数与列表使用同一权限/账户范围，按对象去重，不用全局故障总数代替个人待办。
""", """
| Group | Entries |
| --- | --- |
| Daily work | Chat, Cases, Reports |
| Operations | Plans & Changes, Resources, Schedules |
| Administration | Runtime overview, Agent metrics, Skills, Galaxy, Security, Settings |

Routing precedence: **valid object deep link > pinned home > valid authorised last location > Chat**. Restoration applies only at `/app`; preferences never override an explicit page. Preserve an allow-listed login return route. Deleted/inaccessible objects show a clear fallback to the relevant list without exposing titles.

Add frontend routes `/app/overview`, `/app/resources`, `/app/plans/:id` for overview, resource inventory and fix-plan detail. Retain existing issue, change, session and report detail routes. Preserve compatibility with `/app/issues?view=resources&type=...` and `/app/plans?tab=fix|changes|audit`, including filters. Version and migrate saved navigation ordering rather than clearing it.

Text drafts are namespaced by installation, user and session; files and streaming state by session. In the first delivery, unsent files must be reselected after browser refresh, with an explicit message. Attachment replay is not claimed. Locale changes and in-app navigation preserve drafts.

“Needs your attention” contains objects with an explicit next action and links directly to approval, clarification or verification. Count and rows share authorisation/account filters and object deduplication. A global incident count is not a personal task count.
"""),
("design", "state", "状态表达与事实边界", "State presentation and factual boundaries", """
保留数据库原始状态，增加只读展示投影，不把 UI 标签写回业务状态。一个 Case 分开展示事件生命周期、调查阶段、方案状态、执行状态、恢复验证。Plan 的 `executed` 与 Execution 的 `succeeded` 均不能单独证明业务恢复。

| 对象 | 后端已有状态/标识 | 展示约束 |
| --- | --- | --- |
| HealthIssue | open → investigating 等 → resolved；另有 dismissed | “已关闭/人工接受”和“验证通过”分开 |
| RCA | 独立 RCAResult、evidence、critic/human verdict | 结论、来源、未知事项分开；模型自评不当作事实概率 |
| FixPlan | draft/pending_approval/approved/executing/executed/failed/rejected | 批准不等于执行；`plan_kind=change` 的操作走 Change 服务 |
| ChangeRequest | under_review/needs_clarification/planned/approved/executing/needs_review 等 | 需求评审与方案审批保留区别 |
| FixExecution | pending/running/succeeded/failed/rolled_back/aborted | 保留每次尝试，不用旧执行结果覆盖当前状态 |
| Verification（拟补） | not_run/pending/passed/failed/inconclusive/not_applicable/accepted_manual | 空结果、缺项、重复 check_id、旧版本不能判 passed |

验证记录绑定 `execution_id + plan_content_version + check_id + target + evidence_ref`。必须覆盖全部预期检查且属于当前成功执行。人工验收使用 accepted_manual，显示操作者和原因。9 月审阅中“重复检查仍被判通过”的反例进入 P4 验收。

资源使用数据库整数主键作为路由 ID；云端 ID 是另一字段。规范身份至少包含 provider/account/region/type/native ID 或完整 ARN。不能用名称或裸 ID 的第一个匹配直接跳转。不能确定时保留 unanchored/ambiguous。

图是按需加载的局部证据，必须能表达事实版本、观测时间、来源、可用性与截断。关系不直接等于故障因果。旧图缺字段时显示未知并限制依赖该信息的自动决策；本轮不进行存储介质迁移。
""", """
Retain raw database statuses and add read-only presentation projections. Never write UI labels back as lifecycle state. A case separately shows lifecycle, investigation, plan, execution and recovery verification. Neither Plan `executed` nor Execution `succeeded` alone proves business recovery.

| Object | Existing state/identity | Presentation rule |
| --- | --- | --- |
| HealthIssue | open → investigating etc. → resolved; also dismissed | Closure/manual acceptance differs from verified recovery |
| RCA | RCAResult, evidence, critic/human verdict | Separate finding, sources and unknowns; model self-assessment is not factual probability |
| FixPlan | draft/pending_approval/approved/executing/executed/failed/rejected | Approval is not execution; `plan_kind=change` uses Change actions |
| ChangeRequest | under_review/needs_clarification/planned/approved/executing/needs_review etc. | Request review differs from plan approval |
| FixExecution | pending/running/succeeded/failed/rolled_back/aborted | Keep attempts distinct; old results do not overwrite current state |
| Verification (proposed) | not_run/pending/passed/failed/inconclusive/not_applicable/accepted_manual | Empty, missing, duplicate or stale checks cannot pass |

Bind results to `execution_id + plan_content_version + check_id + target + evidence_ref`. All expected checks must occur once and belong to the current successful execution. Human acceptance uses accepted_manual with actor and reason. The September duplicate-check false-pass counterexample becomes a P4 acceptance test.

Resource routes use the database integer key; the cloud-native ID is a separate field. Canonical identity includes provider/account/region/type/native ID or a complete ARN. Do not link to the first name/bare-ID match. Preserve unanchored/ambiguous when unresolved.

Graphs are bounded, on-demand evidence with fact revision, observation time, provenance, availability and truncation. Relationships do not establish causation. Missing legacy metadata remains unknown and limits graph-dependent automatic decisions. No storage-engine migration is part of this UI work.
"""),
("api", "reuse", "现有接口对接矩阵", "Existing API integration matrix", """
**以已有接口为主体，补齐少量读取和版本契约。** 完整 231 个 API 操作见接口目录与原始 OpenAPI；以下是新界面的主要调用链。路径中的 ID 类型以 OpenAPI 为准，不能把范本中的 `I-2401/P-126` 字符串直接作为真实主键发送。

| 能力 | 已有方法与路径 | 调用约定 |
| --- | --- | --- |
| 登录/用户 | POST `/api/auth/login`；GET `/api/users/me` | 登录字段为 email/password；复用 Bearer，账号输入可以是当前系统支持的 admin |
| 会话管理 | GET/POST `/api/chat/sessions`；GET/PATCH/DELETE `/api/chat/sessions/{session_id}` | session_id 为 UUID 字符串，不是会话表整数 ID |
| 历史与发送 | GET/POST `/api/chat/sessions/{session_id}/messages` | GET 返回 messages/has_more/next_cursor；POST 返回 SSE |
| Cases | GET `/api/health-issues`、`/{issue_id}` | 返回 HealthIssue；旧 `/api/issues`、`/api/anomalies` 兼容保留 |
| RCA/方案生成 | GET/POST `/api/health-issues/{issue_id}/rca`；POST `/{issue_id}/generate-fix-plan` | GET RCA 是列表；生成请求不等于完成 |
| 事件关联 | GET `/api/health-issues/{issue_id}/fix-plans`、`/executions`、`/timeline` | 选定事件后按需读；列表摘要使用批量投影 |
| 反馈 | POST `/api/health-issues/{issue_id}/rca-feedback`、`/feedback` | 保留现有反馈语义，身份由服务端确定 |
| 修复方案 | GET `/api/fix-plans`、`/{plan_id}`；PUT `/{plan_id}` | 只编辑允许的内容字段；状态变更走专用操作 |
| 修复审批/执行 | **PUT** `/api/fix-plans/{plan_id}/approve`；POST `/reject`、`/execute` | 修复批准是 PUT；不能统一改成 POST |
| 变更工作流 | GET/POST `/api/changes`；GET `/{cr_id}`；POST `/approve`、`/reject`、`/clarify`、`/review`、`/execute`、`/cancel`、`/resolve-review` | 变更审批/执行始终使用 ChangeRequest ID |
| 执行 | GET `/api/fix-executions`、`/{execution_id}`；POST `/{execution_id}/cancel` | POST execute 的 202 返回执行记录；取消是独立操作 |
| 资源 | GET `/api/resources`、`/{resource_id}`、`/issues`、`/fix-plans`、`/related` | 列表是 `{total,items}`，不同于 Issue/Plan 的数组 |
| 报告 | GET `/api/reports`、`/{report_id}`；POST `/generate`、`/from-session`、`/{report_id}/publish` | 发布会调用外部渠道；浏览、导出和发布分开 |
| 搜索/审计 | GET `/api/search`；现有 audit、command-audits、trace 路由 | 搜索结果保留对象类型与 ID；权限由服务端裁剪 |
| Graph/其他 | 现有 `/api/graph/*`、`/api/galaxy/*`、Schedules、Skills、Security、Messaging、Accounts、Settings | 全部保留；局部图不作为首屏阻塞请求 |

通用 API 客户端目前默认 JSON，不用于 multipart 或二进制下载。实施时拆分 `requestJson`、`requestMultipart`、`requestStream`、`downloadBlob`，共用认证、401 回跳、错误解码和 trace ID；保留 TanStack Query 和现有会话流 store。
""", """
**Reuse existing APIs and add a small set of read/revision contracts.** The full 231-operation API inventory is included with the unchanged OpenAPI. This table covers the main UI journeys. ID types follow OpenAPI; sample labels such as `I-2401/P-126` must not be sent as real primary keys.

| Capability | Existing method/path | Contract |
| --- | --- | --- |
| Login/user | POST `/api/auth/login`; GET `/api/users/me` | email/password input; existing Bearer token |
| Sessions | GET/POST `/api/chat/sessions`; GET/PATCH/DELETE `/api/chat/sessions/{session_id}` | UUID session_id, not the integer session table key |
| History/send | GET/POST `/api/chat/sessions/{session_id}/messages` | GET: messages/has_more/next_cursor; POST: SSE |
| Cases | GET `/api/health-issues`, `/{issue_id}` | Canonical HealthIssue; retain legacy `/api/issues` and `/api/anomalies` |
| RCA/plan generation | GET/POST `/api/health-issues/{issue_id}/rca`; POST `/{issue_id}/generate-fix-plan` | RCA GET returns a list; accepted generation is not completion |
| Related case data | GET `/api/health-issues/{issue_id}/fix-plans`, `/executions`, `/timeline` | Fetch after selection/on demand; batch summaries for the queue |
| Feedback | POST `/api/health-issues/{issue_id}/rca-feedback`, `/feedback` | Preserve semantics; actor comes from the server |
| Fix plans | GET `/api/fix-plans`, `/{plan_id}`; PUT `/{plan_id}` | Content-only edits; dedicated lifecycle actions |
| Fix approval/execution | **PUT** `/api/fix-plans/{plan_id}/approve`; POST `/reject`, `/execute` | Fix approval is PUT, not POST |
| Changes | GET/POST `/api/changes`; GET `/{cr_id}`; POST `/approve`, `/reject`, `/clarify`, `/review`, `/execute`, `/cancel`, `/resolve-review` | Always act with ChangeRequest ID through the Change service |
| Executions | GET `/api/fix-executions`, `/{execution_id}`; POST `/{execution_id}/cancel` | Execute 202 returns an execution record; cancellation is separate |
| Resources | GET `/api/resources`, `/{resource_id}`, `/issues`, `/fix-plans`, `/related` | List shape is `{total,items}`, unlike issue/plan arrays |
| Reports | GET `/api/reports`, `/{report_id}`; POST `/generate`, `/from-session`, `/{report_id}/publish` | Publication sends externally; reading/export/publication are separate |
| Search/audit | GET `/api/search`; existing audit, command-audits and trace routes | Typed object references and server-side access filtering |
| Graph/others | Existing graph, galaxy, schedules, skills, security, messaging, accounts and settings | Retained; local graph does not block the first screen |

The current API helper assumes JSON. Separate `requestJson`, `requestMultipart`, `requestStream` and `downloadBlob`, sharing auth, login return routes, error decoding and trace IDs. Retain TanStack Query and the existing session stream store.
"""),
("api", "gaps", "必须修正的契约差异", "Contract gaps that affect implementation", """
| 编号 | 当前观察 | 实施决定 |
| --- | --- | --- |
| G1 | `/api/issues` 使用 AnomalyResponse 投影；前端仍用 useAnomalies | 新 Cases 使用 HealthIssue 类型/接口；旧入口留作兼容 |
| G2 | 发送消息运行时是 POST SSE，但 OpenAPI 声明为 JSON 且缺请求体 | 补 JSON/multipart/SSE 文档，保留实际协议与事件名 |
| G3 | ChatSessionCreate 只有 name，没有账户/对象上下文；会话列表查询未按所有者裁剪 | 增加 context、scope 和可见性规则，所有会话读写检查身份；不要仅把标题放进 prompt |
| G4 | FixPlanResponse 没有内容版本；approve 会调用 trigger_auto_execute | 版本/范围与并发条件写入服务层；确认按钮显示“批准”或“批准并排队执行”的真实效果 |
| G5 | 报告有正文与格式转换，但没有正式的中英文版本读取契约 | 以源版本生成语言渲染；导出/发布绑定版本、语言、格式 |
| G6 | HealthIssueUpdate 状态 pattern 缺 dismissed；模型状态机有 dismissed | 对齐可执行状态与权限；关闭不能用任意字符串 PUT 绕过状态机 |
| G7 | ReportGenerateRequest 接受的类型多于 generate handler 实际处理的类型 | 修正声明或实现支持；前端仅显示已支持的生成类型 |
| G8 | 现有 Chat 停止方式为 AbortController；刷新断流不等于持久任务恢复 | 保留跨路由流 store；刷新后读历史并标识中断；禁止自动重新提交写操作 |
| G9 | 规范资源锚定、图事实新鲜度、验收绑定在历史审阅中仍有缺口 | 先显式 unknown/ambiguous；依赖它们的写操作在条件满足后启用 |
| G10 | 企业微信 GET/POST 回调在 OpenAPI 中共用 operationId | P0 给两个操作分配独立编号，仅修正文档，不改变回调行为 |
| G11 | RCA 触发的 202 被声明为 RCAResponse，实际返回 message/health_issue_id；方案生成也返回受理对象 | P0 对齐受理响应；前端通过结果/时间线读取完成情况 |

这些属于源码/声明的核对结果，不代表本次已修复。身份隔离、写操作并发与验证完整性属于客户上线门槛；页面视觉改造不应掩盖这些条件。
""", """
| ID | Current observation | Implementation decision |
| --- | --- | --- |
| G1 | `/api/issues` exposes an AnomalyResponse projection; frontend uses useAnomalies | New Cases use HealthIssue types/endpoints; retain compatibility |
| G2 | Message POST is SSE at runtime; OpenAPI declares JSON without its body | Document JSON/multipart/SSE, preserving actual event names |
| G3 | Chat creation has only name; no object/account context, and session listing is not owner-filtered | Add validated context/scope/visibility and check every session read/write; a prompt title is insufficient |
| G4 | FixPlanResponse has no content version; approve invokes trigger_auto_execute | Bind revision/scope atomically; confirmation reflects approve-only versus approval plus execution queuing |
| G5 | Reports support bodies/formats but lack a formal bilingual revision contract | Render from a source version; pin export/publication to version, language and format |
| G6 | HealthIssueUpdate excludes dismissed although the model state machine supports it | Align supported actions and permission checks; no arbitrary state-string bypass |
| G7 | ReportGenerateRequest allows more report types than the handler implements | Align declaration/implementation; expose only supported generation options |
| G8 | Chat stop uses AbortController; refresh/disconnect is not durable task recovery | Keep the route-independent stream store, reconcile history and label interrupted turns; never automatically resubmit writes |
| G9 | Prior review identifies gaps in resource identity, graph freshness and verification binding | Show unknown/ambiguous explicitly; enable dependent writes only after their prerequisites are met |
| G10 | WeCom GET/POST callbacks share an OpenAPI operationId | Assign distinct IDs in P0; documentation-only repair, preserving callback behavior |
| G11 | RCA trigger declares RCAResponse for 202 but returns message/health_issue_id; plan generation also returns acceptance | Align accepted-response schemas in P0; read completion from results/timeline |

These are source/contract observations, not fixes completed in this delivery. Identity isolation, write concurrency and complete verification are customer-release gates; visual changes must not conceal them.
"""),
("api", "new-api", "新增接口：8 个操作", "New APIs: eight operations", """
目标 OpenAPI 明确标记 `proposed-new` / `proposed-extension` / `existing-retained`。**拟新增 8 个操作，扩展 32 个现有操作；其余保持原路由。** 目标文件是设计合同，不是已运行服务。

扩展清单中 4 项仅修正文档：企业微信 GET/POST 的独立 operationId，以及 RCA/方案生成的 202 受理响应。它们不改变运行行为。

| 方法/路径 | 目的 | 阶段 |
| --- | --- | --- |
| GET `/api/ui/bootstrap` | 当前身份、能力开关、实际上传策略、偏好；不暴露渠道密钥 | P1 |
| GET `/api/users/me/preferences` | 当前用户首页、语言、合法恢复路由与版本 | P1 |
| PATCH `/api/users/me/preferences` | 更新偏好；If-Match 防止多标签覆盖 | P1 |
| GET `/api/ui/attention` | 统一权限/账户范围的可操作待办 | P4 |
| POST `/api/health-issues/{issue_id}/notes` | 向现有时间线追加有操作者的说明 | P3 |
| GET `/api/content/{entity_type}/{entity_id}/rendering` | 读取指定版本的 zh/en 展示正文；GET 不调用模型 | P5 |
| POST `/api/content/{entity_type}/{entity_id}/translations` | 保证指定源版本的语言渲染存在，返回 ready/pending；可幂等重用 | P5 |
| GET `/api/reports/{report_id}/export` | 下载固定 version/language/format 的文件，不发布 | P5 |

`entity_type` 限定 health_issue、fix_plan、change_request、report。共用渲染服务，避免为每个页面各建翻译 API。`language=zh-en` 仅用于导出两份已准备好的语言正文，翻译任务仍分别生成 zh 和 en。

GET bootstrap 的字段表示**有效能力**：例如 revision_guards、context_chat、content_rendering。未部署的新接口不能被前端乐观假定为存在。P1 可先接旧读取能力；P4 写操作仅在版本保护被后端实际启用后开放。
""", """
Target OpenAPI marks `proposed-new`, `proposed-extension` and `existing-retained`. **Eight operations are proposed as new; 32 existing operations are extended; remaining routes are retained.** The target document is a design contract, not the running service.

Four extensions are documentation-only: separate WeCom GET/POST operation IDs and the accepted-response schemas for RCA/plan generation. They do not change runtime behavior.

| Method/path | Purpose | Phase |
| --- | --- | --- |
| GET `/api/ui/bootstrap` | Identity, effective capabilities, upload policy and preferences; no connector secrets | P1 |
| GET `/api/users/me/preferences` | Home, locale, allow-listed last route and revision | P1 |
| PATCH `/api/users/me/preferences` | Update preferences with If-Match concurrency | P1 |
| GET `/api/ui/attention` | Actionable work under one actor/account scope | P4 |
| POST `/api/health-issues/{issue_id}/notes` | Append an attributed note to the existing timeline | P3 |
| GET `/api/content/{entity_type}/{entity_id}/rendering` | Read zh/en presentation for an exact source version; no model call on GET | P5 |
| POST `/api/content/{entity_type}/{entity_id}/translations` | Ensure requested source-version renderings; return ready/pending and deduplicate | P5 |
| GET `/api/reports/{report_id}/export` | Download a pinned version/language/format without publishing | P5 |

Supported entity_type values are health_issue, fix_plan, change_request and report. A shared rendering service avoids separate translation APIs per page. `language=zh-en` is an export of two prepared renderings; translation produces zh and en separately.

Bootstrap advertises **effective capabilities** such as revision_guards, context_chat and content_rendering. The frontend must not assume undeployed APIs exist. P1 may use existing reads; P4 writes open only after the backend actually enforces revision protection.
"""),
("api", "chat-contract", "Chat、附件与流式契约", "Chat, attachments and streaming", """
新会话仍使用现有 POST，拟增加可验证的上下文。以下是**目标契约示例**，不能向当前服务发送后就假定 context 已被执行：

```json
{
  "name": "订单服务排查",
  "response_language": "zh",
  "context": {
    "primary": {"entity_type": "health_issue", "entity_id": 42, "content_version": 1},
    "account_id": 3,
    "region": "ap-southeast-1"
  }
}
```

独立请求使用 `primary:null`；关联对象的范围由服务端解析。首次发送后上下文锁定，改范围创建新会话；每次工具调用仍检查当前权限与范围，不能靠前端下拉框实现隔离。

发送消息：`POST /api/chat/sessions/{session_id}/messages`，文本为 `{content, client_message_id, scan_focus?}`；多附件为 multipart，字段 `content`、`client_message_id`、重复的 **file**。当前服务上限 5 个。原生图片与原生文档 5 MiB，文本回退 512 KiB；`.txt/.md/.csv/.html` 当前优先走原生文档分支，不要用“所有文本都 512 KiB”的错误规则。

复用 `text`、`tool_start`、`tool_end`、`session_renamed`、`done`、`error` 事件。新增 accepted 帧和稳定消息/调用标识；传输层按完整 SSE 帧解析，支持 UTF-8 拆包、跨 chunk、CRLF 和未知事件。`tool_end` 不能仅凭工具名称表达成功。

`client_message_id` 在同一会话唯一；事务中记录请求指纹与 dispatch 状态。已完成的重复请求可重放持久消息，正在执行/状态不确定的重复请求返回 409，不能再次启动 Agent。断线不自动 POST 重试。终止回复标为 interrupted；已有工具副作用需回到 Case/Execution 核对。

第一阶段不新增 `/runs` 平台、不承诺刷新后无损 SSE 回放、不增加语音/视频入口。当前附件元数据只有文件名/大小/类型，不能伪装成可重下载的附件 ID。持久附件与真正后台可恢复 Chat 作为后续独立阶段。
""", """
Keep the existing create-session POST and extend it with validated context. This is a **target example**; sending it to the current service does not mean context enforcement exists:

```json
{
  "name": "Order service investigation",
  "response_language": "en",
  "context": {
    "primary": {"entity_type": "health_issue", "entity_id": 42, "content_version": 1},
    "account_id": 3,
    "region": "ap-southeast-1"
  }
}
```

Independent requests use `primary:null`. The server resolves linked-object scope. Lock context after the first send; create a new session to change it. Every tool call checks current permissions and scope. A frontend selector is not an isolation boundary.

POST messages as JSON `{content, client_message_id, scan_focus?}` or multipart fields `content`, `client_message_id` and repeated **file**. The existing limit is five files. Native images/documents allow 5 MiB; text fallback allows 512 KiB. `.txt/.md/.csv/.html` currently dispatch to native documents first; “all text is limited to 512 KiB” would be incorrect.

Reuse text, tool_start, tool_end, session_renamed, done and error. Add accepted and stable message/tool-call identifiers. Parse complete SSE frames across UTF-8/chunk boundaries and CRLF; tolerate unknown events. A tool_end name alone cannot imply success.

client_message_id is unique within the session, with an atomic request fingerprint and dispatch state. Completed duplicates may replay persisted output; active/uncertain duplicates return 409 and never restart the Agent. Do not retry POST automatically after disconnect. Label interrupted replies and inspect Case/Execution for effects already performed.

The first release adds no generic `/runs` platform, lossless refresh-time SSE replay, voice or video. Current attachment metadata has filename/size/type rather than retrievable attachment IDs. Durable attachment storage and independently resumable background Chat remain separate follow-up work.
"""),
("api", "mutation", "审批、执行与验收契约", "Approval, execution and verification contract", """
保留现有操作方法，增加强 ETag 和条件请求。示例中的 ETag 是说明用值：

```http
GET /api/fix-plans/126
Authorization: Bearer <token>

HTTP/1.1 200 OK
ETag: "plan-126-v3-state7-scope9"
```

```http
PUT /api/fix-plans/126/approve
Authorization: Bearer <token>
If-Match: "plan-126-v3-state7-scope9"
Idempotency-Key: 35ac86c5-5779-4462-a815-d635f87cf09b
Content-Type: application/json

{"reason":"已核对目标、验证和回滚条件"}
```

服务端从登录身份确定 actor；忽略客户端自报 approved_by 作为权限依据。版本、目标范围、策略与状态在**同一事务**中核对和转移。内容改变递增 content_version；审批记录保留版本与范围指纹；执行记录引用批准的不可变快照。

| 返回 | 前端行为 |
| --- | --- |
| 202 | 已受理，追踪返回的 execution_id；不能立即显示执行成功 |
| 403 | 显示不可执行原因，保留只读上下文 |
| 409 | 状态冲突/重复请求，读取最新对象并说明原因 |
| 412 | 已审阅版本过期，刷新差异后重新确认 |
| 428 | 缺少版本条件；不静默降级为无条件写入 |

Idempotency-Key 是本项目拟实施的服务层契约，不是已有中间件能力。幂等记录绑定 actor、路由、规范请求体与结果；同 key 不同内容返回 409。升级顺序为服务端可选能力 → 新前端携带条件 → 迁移 CLI/IM/旧前端 → 全局强制。

特别处理：Fix approve 当前可能自动排队执行。读取 `available_actions.effect` 决定确认文字和后续界面；不要批准后再自动发一次 execute。Change 的 approve/execute 委托 Change 服务，不能通过其底层 FixPlan 绕行。

任何“恢复通过”必须由 verification_service 检查当前执行、版本、稳定 check_id、唯一覆盖、目标和工具证据。重复 A 缺少 B、旧执行迟到结果、失败执行带 pass 字段、人工接受都不得自动变成机器 passed。已有 Change resolve-review 复用该服务。
""", """
Preserve current methods and add strong ETags/preconditions. The ETag below is illustrative:

```http
GET /api/fix-plans/126
Authorization: Bearer <token>

HTTP/1.1 200 OK
ETag: "plan-126-v3-state7-scope9"
```

```http
PUT /api/fix-plans/126/approve
Authorization: Bearer <token>
If-Match: "plan-126-v3-state7-scope9"
Idempotency-Key: 35ac86c5-5779-4462-a815-d635f87cf09b
Content-Type: application/json

{"reason":"Reviewed target, verification and rollback"}
```

The server derives the actor from authentication. Client-claimed approved_by is not authority. Check revision, scope, policy and state **in the same transaction** as transition. Content changes increment content_version; approval records bind version/scope; execution references the approved immutable snapshot.

| Response | UI behavior |
| --- | --- |
| 202 | Accepted; track execution_id, not success |
| 403 | Show denial reason while retaining read context |
| 409 | State/duplicate conflict; read latest object and explain |
| 412 | Reviewed revision is stale; refresh differences and reconfirm |
| 428 | Revision precondition missing; no silent unconditional fallback |

Idempotency-Key is a proposed application-service contract, not existing middleware. Bind actor, route, canonical request and result. Same key with different content returns 409. Roll out optional backend capability, conditional new frontend, migration of CLI/IM/old clients, then global enforcement.

Fix approval may currently auto-queue execution. Use available_actions.effect for confirmation and follow-up; do not automatically call execute again after approval. Change actions delegate to the Change service rather than its underlying FixPlan endpoints.

verification_service checks current execution/version, stable unique check IDs, complete coverage, target and tool evidence. Duplicate A with missing B, late old attempts, failed execution with pass text and human acceptance cannot manufacture machine passed. Existing Change resolve-review delegates to this service.
"""),
("api", "language", "双语正文、报告与下载", "Bilingual content, reports and download", """
UI 字典沿用现有 LocaleContext/locales；规范 API 状态与 ID 不翻译。Case 结论、Plan 说明、Change 需求说明和 Report 正文使用共用 ContentRendering，键为 `(entity_type, entity_id, source_version, language)`，同时保存 source_hash 与受保护事实的指纹。

新内容生成后准备 zh/en 两个渲染；切换语言只读取已生成内容。历史单语言内容缺翻译时显示“翻译准备中/不可用”和源语言入口，不静默混排，也不重新做 RCA 或生成另一份方案。原始用户请求保留原文，译文明确作为展示内容。

渲染不改变命令、标识、证据引用、检查项 ID、数值和状态。渲染的 ready 状态要求源 hash 与受保护字段核对通过。源发生变化时旧渲染标记 stale。报告语言版本不作为新的批准对象。

```http
GET /api/content/report/42/rendering?version=2&language=zh
GET /api/reports/42/export?version=2&language=zh-en&format=html
```

导出用带认证的 fetch 获取 Blob，再用 Content-Disposition 保存；普通 JSON 客户端不能直接处理。下载路径不携带 token。HTML/PDF/DOCX 三种格式延续既有报告转换能力；能力不可用时明确禁用对应格式。首次交付必须通过 HTML 和浏览器打印验收，PDF/DOCX 在客户安装对应依赖后验证。

发布扩展已有 `/api/reports/{id}/publish`：固定 version、language、formats、channel_name 和幂等键。展示实际目的地后才发送。已有 publish 支持 sns-report / ses 渠道，不把所有 IM 频道假设为发布目标。普通分享功能保留，但不能绕开报告版本绑定。
""", """
Reuse LocaleContext/locales for UI text; never translate canonical status values or IDs. Case findings, plan explanations, change request descriptions and report bodies share ContentRendering keyed by `(entity_type, entity_id, source_version, language)`, with source_hash and a protected-facts fingerprint.

Prepare zh/en renderings after new source content is generated. Locale switching only reads prepared content. Legacy content without a translation shows preparing/unavailable plus an explicit source-language option; it never silently mixes languages, restarts RCA or creates another plan. Preserve original user requests; translated text is presentation.

Rendering must not alter commands, identifiers, evidence/check references, values or states. Ready requires source-hash and protected-value validation. Source changes mark old renderings stale. Report language variants do not become new approval objects.

```http
GET /api/content/report/42/rendering?version=2&language=zh
GET /api/reports/42/export?version=2&language=zh-en&format=html
```

Download via authenticated fetch/Blob and Content-Disposition, not the JSON helper. Do not place tokens in URLs. Reuse existing HTML/PDF/DOCX conversion capabilities and disable unavailable formats. HTML and browser printing are required initially; validate PDF/DOCX where customer dependencies are installed.

Extend existing report publication with pinned version, language, formats, channel_name and idempotency. Show the actual destination before sending. Existing publish supports sns-report/ses; do not assume all IM channels are publishing targets. Retain general sharing without bypassing report revision binding.
"""),
("api", "performance", "查询、缓存与错误处理", "Queries, caching and errors", """
- 列表默认 50 条、服务端筛选和分页。Case 队列所需状态批量查询；禁止每条记录再请求 RCA、Plan、Execution。
- 进入详情后并行读取独立信息；原始日志、大 JSON、时间线旧页和图在展开时加载。图请求限制深度、节点数和账户范围，并显示截断。
- Query key 包含对象 ID、账户范围、语言和内容版本；UI 语言缓存与事实查询分离，切语言不重新执行诊断。
- 复用已有会话流 store，页面离开不销毁流。执行中的记录使用短轮询，终态停止；重新聚焦时检查失效数据。
- 写操作成功后刷新关联 Case、Plan、Change、Execution 与待办；不能只更新一个绿色徽标。状态冲突必须重新读服务端。
- 统一加载、空、无权限、已删除、离线、部分失败和翻译准备状态。新错误结构为 detail/code/trace_id，适配器同时识别已有 FastAPI 422 和旧 error 格式。

验收预算属于**目标而非测量结果**：在客户约定的本地数据规模下，50 条 Case 首屏接口 p95 ≤500ms、详情数据 p95 ≤800ms；不计云实时诊断时间。记录请求数、SQL 次数、正文/图 payload、浏览器长任务和首次可操作时间。未达预算时先修 N+1、分页、索引和懒加载，不先更换数据库。
""", """
- Default to 50-row server-filtered pages. Batch case-queue status summaries; do not fetch RCA/Plan/Execution once per row.
- Fetch independent detail data concurrently. Load raw logs, large JSON, old timeline pages and graphs on demand. Bound graph depth/nodes/account and disclose truncation.
- Query keys include object, account, language and content revision. Separate translation caches from fact queries; locale changes do not run diagnosis.
- Retain the existing session stream store across navigation. Poll active executions briefly, stop at terminal states and reconcile stale data on focus.
- Mutations invalidate related case, plan, change, execution and attention data, not just one badge. State conflicts trigger a server re-read.
- Provide loading, empty, denied, deleted, offline, partial-failure and translation-preparing states. New errors use detail/code/trace_id while adapters retain FastAPI 422 and legacy error support.

Acceptance budgets are **targets, not measurements**: with an agreed customer-local dataset, p95 ≤500ms for a 50-case page and ≤800ms for detail data, excluding live cloud investigation. Measure requests, SQL counts, payloads, browser long tasks and time to first action. Address N+1, pagination, indexing and lazy loading before changing storage engines.
"""),
("plan", "phases", "分阶段实施计划", "Phased implementation plan", """
| 阶段 | 范围与主要文件 | 完成条件 | 依赖 |
| --- | --- | --- | --- |
| P0 基线 | 冻结 OpenAPI/源码指纹；确认旧链接与状态；生成契约类型；准备隔离样例 | 现有/扩展/新增一一对应；不连接云执行 | 无 |
| P1 外壳 | App.tsx、AppShell/NavItems、index.css、LocaleContext；新增 HomeResolver、偏好/能力接口 | 蓝白主题、三主入口、恢复/固定首页、登录回跳、旧链接正常 | P0 |
| P2 Chat | Chat.tsx、ChatComposer、chatStream.ts、useChatMessages/useSessionStream；会话上下文/身份/幂等扩展 | 独立与关联会话、真实多附件、流错误/中断、不重复提交、范围隔离 | P1 |
| P3 Cases/Resources | IssuesAndPlans、IssueDetail、ResourceDetail；新增 useHealthIssues 与只读适配器；notes/summary | 列表详情、真实证据/状态、资源身份歧义、完整保留操作入口 | P1，可与 P2 分支并行 |
| P4 Plans/Attention | PlansAndChanges、ChangeDetail、components/plans；版本/验证服务、条件写入和待办 | 版本过期拒绝、并发唯一执行、Fix/Change 正确路由、验证不可伪造 | P2/P3 的上下文与类型 |
| P5 Reports/双语 | Reports、ReportDetail、报告生成/发布；ContentRendering 与 export | zh/en/zh-en 同源版本；导出/打印；明确的真实发布确认 | P3/P4 内容版本 |
| P6 联合验收/发布 | API/前端测试、构建、客户同源部署、迁移与回退演练 | 所有验收通过，默认只读演练完成，目标环境写操作另行启用 | P1–P5 |

建议每阶段独立 PR，先交付可体验的外壳与只读页面，再开放写操作。后端接口与对应前端一起验收，避免一次全量重写。工作量与日历日期在 P0 基线测试后估算；本计划不以未测量的工期承诺替代依赖关系。
""", """
| Phase | Scope and main files | Exit condition | Dependency |
| --- | --- | --- | --- |
| P0 Baseline | Freeze OpenAPI/source fingerprints, old links/states; derive types and isolated fixtures | Existing/extended/new mapping; no cloud execution | None |
| P1 Shell | App.tsx, AppShell/NavItems, index.css, LocaleContext; HomeResolver, preferences/capabilities | Blue/white, three primary entries, restore/pin home, login return, compatible links | P0 |
| P2 Chat | Chat.tsx, ChatComposer, chatStream.ts, history/stream hooks; context/identity/idempotency | Independent/context chats, real attachments, errors/interruption, no duplicate dispatch, scoped access | P1 |
| P3 Cases/Resources | IssuesAndPlans, IssueDetail, ResourceDetail; canonical hooks/read adapters; notes/summary | List/detail, real evidence/state, identity ambiguity, retained operations | P1; may branch in parallel with P2 |
| P4 Plans/Attention | PlansAndChanges, ChangeDetail, plan components; revision/verification services, conditional writes, attention | Stale revision rejection, one concurrent execution, correct fix/change routing, valid evidence checks | P2/P3 context and types |
| P5 Reports/languages | Reports, ReportDetail, generator/publisher; ContentRendering/export | Same-source zh/en/zh-en, export/print, explicit real publication | P3/P4 content revisions |
| P6 Integration/release | API/UI tests, build, customer same-origin deployment, migration/rollback rehearsal | Acceptance passes, read-only rehearsal, deliberate enablement of target-environment writes | P1–P5 |

Use one reviewable PR per phase. Deliver the shell and read views before opening write actions. Accept backend and corresponding UI together instead of a full rewrite. Estimate calendar effort after P0 baseline testing; this plan does not substitute an unmeasured deadline for dependencies.
"""),
("plan", "tasks", "可执行任务与验收", "Executable work items and acceptance", """
| 任务 | 实施与验收要求 |
| --- | --- |
| P0.1 契约基线 | 重新导出 OpenAPI，与本次快照 diff；测试命令/环境记录在 PR；识别用户既有未提交修改 |
| P0.2 类型与样例 | 为 SSE、ResourcePage、HealthIssue、Change、版本渲染补类型；正常/空/失败/无权限样例不使用客户敏感数据 |
| P1.1 导航/路由 | 主入口与工具分组；保留全部已有模块；迁移拖动排序；覆盖首访、固定首页、恢复、404/403、登录深链 |
| P1.2 样式/i18n | 复用蓝白 token，统一间距、状态、焦点；中英文键完整；本地字体与已有字体大小设置 |
| P2.1 上下文 | DTO、数据库字段、服务端解析和工具 RunContext；自由需求不创建 Issue；不能跨账户借用上下文 |
| P2.2 生命周期 | 会话创建/改名/置顶/收藏/归档/删除仍可用；明确 private/workspace 可见性；旧会话迁移不任意归属 |
| P2.3 发送与文件 | 5 文件、类型/字节限制、粘贴/拖入/移除；JSON与multipart；非文本内容传给真实多模态通路 |
| P2.4 流与幂等 | UTF-8/跨包解析、401/429/5xx、断网、重复 client_message_id、会话并发、刷新中断；停止回复不显示云回滚成功 |
| P3.1 Cases | 从 Anomaly 类型迁移；筛选/分页/选择状态在 URL 中；最新 RCA 与执行按明确排序选取；原始证据按需加载 |
| P3.2 Resources | integer ref 与 native ID 分开；同名跨账户/区域/类型测试；无法锚定时显示候选，不跳第一个匹配 |
| P3.3 说明/状态 | 说明追加时间线；source/status/timestamp 保留；关闭/误报/反馈遵守现有服务语义与权限 |
| P4.1 版本迁移 | Plan 内容快照、scope hash、Execution 引用、稳定 check_id；旧不可证实结果保留 inconclusive |
| P4.2 决策操作 | 过期页面、双人并发、重复按钮、同 key 不同 body、auto-execute、Change旁路拒绝；校验必须在事务内 |
| P4.3 验收/待办 | 重复检查/缺项/旧结果/迟到回调/人工接受；待办计数与授权列表一致，终态后移除 |
| P5.1 渲染 | 源版本和受保护值指纹；缺翻译、失败、stale；双语共享引用，不触发再次调查 |
| P5.2 报告交付 | HTML/PDF/DOCX依能力；下载认证；版本和语言固定；发布失败/部分成功/幂等/目标确认 |
| P6.1 回归 | 现有 test_chat_api、test_changes_api、test_fix_plan_hardening_api、test_resource_detail_api 等按改动运行；新增契约/并发/验证测试 |
| P6.2 UI与部署 | npm test、npm run build；浏览器主流程、390/768/1280/1600宽度、键盘；反向代理SSE与深链；保留回退制品 |

未来新增文件建议：`web/routers/ui.py`、`web/routers/content.py`、`services/ui_read_service.py`、`services/content_rendering_service.py`、`services/plan_revision_service.py`、`services/verification_service.py`。这些是**拟新增**，不是当前已有模块。不要把新的页面逻辑继续堆入 21 万字节的 web/app.py。

完成定义：页面上每一个真实可点击操作都有接口、权限、版本和失败语义；未接入项明确禁用/说明。样式通过不能替代接口和执行结果验证。
""", """
| Task | Implementation and acceptance |
| --- | --- |
| P0.1 Baseline | Re-export/diff OpenAPI; record test environment in PR; preserve existing user changes |
| P0.2 Types/fixtures | Type SSE, ResourcePage, HealthIssue, Change and renderings; normal/empty/error/denied fixtures without customer-sensitive data |
| P1.1 Navigation | Primary/tool groups, all modules retained, migrate ordering; first visit, pinned/resume home, 404/403, login deep link |
| P1.2 Style/i18n | Reuse blue/white tokens, spacing/status/focus, complete locale keys, local fonts and font-size preferences |
| P2.1 Context | DTO/storage/resolution/tool RunContext; independent request creates no Issue; no cross-account scope borrowing |
| P2.2 Lifecycle | Preserve create/rename/pin/star/archive/delete; explicit private/workspace visibility; deliberate legacy-session migration |
| P2.3 Files/send | Five files, types/byte caps, paste/drop/remove, JSON/multipart; real multimodal processing |
| P2.4 Stream/idempotency | UTF-8/chunks, 401/429/5xx, offline, duplicate client IDs, concurrent sessions, refresh interruption; stopping text does not imply cloud rollback |
| P3.1 Cases | Replace Anomaly view types, URL-backed filters/selection, explicit latest-result ordering, lazy evidence |
| P3.2 Resources | Integer reference versus native ID; same-name account/region/type collisions; show candidates rather than first-match links |
| P3.3 Notes/state | Attributed timeline notes and source/time preservation; existing service semantics and permissions for dismissal/feedback |
| P4.1 Revisions | Plan snapshots/scope hash, execution binding, stable check IDs; legacy unverifiable data is inconclusive |
| P4.2 Decisions | Stale pages, concurrent approvers, duplicate clicks, key/body conflict, auto-execute and Change bypass; transactional guards |
| P4.3 Verification/attention | Duplicate/missing/stale/late checks and manual acceptance; authorised counts match rows and remove terminal work |
| P5.1 Rendering | Source/protected-value fingerprints, missing/failed/stale translations, same evidence refs without another investigation |
| P5.2 Delivery | Capability-aware formats, authenticated download, pinned language/revision, failure/partial-success/idempotency/destination confirmation |
| P6.1 Regression | Relevant existing chat/change/fix-plan/resource API suites plus new contract/concurrency/verification tests |
| P6.2 UI/deployment | npm test/build; browser journeys at 390/768/1280/1600, keyboard, proxy SSE/deep links, retained rollback artifacts |

Proposed new modules: web/routers/ui.py, web/routers/content.py, services/ui_read_service.py, services/content_rendering_service.py, services/plan_revision_service.py and services/verification_service.py. These are **planned**, not existing. Avoid adding more page logic to the already large web/app.py.

Definition of done: every real enabled action has an API, permission, revision and failure contract. Unintegrated actions are explicit. Passing a visual review does not substitute for integration and execution-result validation.
"""),
("plan", "deployment", "客户环境部署与回退", "Customer deployment and rollback", """
沿用当前同源部署：浏览器访问 `/app/*` 和 `/api/*`，React 构建进入现有 wheel/镜像的 frontend/dist，由 FastAPI 提供。客户反向代理负责 HTTPS、深链和流式转发；初期不拆前后端域名，也不要求客户安装新的数据库。

1. **部署基线**：复用现有容器/EC2 compose 路径，使用客户自己的配置与持久卷。静态字体本地打包。确认 `AIOPS_API_AUTH_ENABLED` 与 `AIOPS_RBAC_ENFORCE` 的有效值；源码默认值不代表客户实例当前值。
2. **启动模型**：现有会话 Agent、后台执行器、scheduler 和 ITSM bridge 存在进程内状态。第一阶段以单应用进程部署；不通过加多个 web worker 伪装扩容，以免重复调度和会话漂移。真正多副本/后台可恢复任务单独设计。
3. **兼容迁移**：先加可空字段/新表，再回填版本与权限数据，最后开 capability。Plan 旧内容可建立迁移快照，但没有执行绑定的历史检查不能回填为 passed。历史会话设为明确的 legacy shared 或经确认的所有者。
4. **隔离验证**：复制脱敏数据库或 fixtures，关闭会触发扫描/执行/外部通知的测试启动项。只读/演示模式验收；真实发送 IM、邮件、ITSM 写入和云变更不是本次文档验证的一部分。
5. **灰度**：按用户/部署 feature flag 开启新壳、Chat、Cases、Plans、Reports；错误率、SSE 中断、重复执行、权限拒绝、导出失败进入上线观测。
6. **回退**：保留旧前端构建与容器制品；关闭新 UI feature flag、恢复旧首页路由。数据库只使用向后兼容增加项，避免当天删列。若已产生新版本审批，不允许回退到会绕过版本保护的写接口；此时保留后端保护、回退 UI 为只读。

已有 ServiceNow/Jira bridge 是 best-effort 生命周期镜像，不等同于已验证的可靠双向审批系统。IM、监控 webhook 与 ITSM 凭据留在服务端。若客户要求可靠外部回调审批，需另行验收签名/防重放、外部身份映射、幂等与状态冲突；禁止浏览器直接连接 ServiceNow 并持有密钥。

UI 可先交付；客户写操作上线必须通过权限、方案版本和验证完整性门槛。Graph 身份/事实服务未满足审阅约束时，相关区块明确降级，不能展示“影响为零”并据此自动批准。
""", """
Retain same-origin deployment: `/app/*` and `/api/*`, with the React build included in the current wheel/image frontend/dist and served by FastAPI. The customer reverse proxy handles HTTPS, deep links and streaming. No separate frontend domain or new database is required initially.

1. **Baseline:** reuse current container/EC2 compose delivery with customer configuration and persistent volumes. Bundle fonts locally. Verify effective API authentication and RBAC settings; source defaults do not reveal the customer runtime values.
2. **Process model:** session Agents, executor, scheduler and ITSM bridge have process-local state. Use one application process initially. Multiple web workers could duplicate scheduling or lose session affinity; real replicas/durable background work need a separate design.
3. **Compatible migration:** add nullable fields/tables, backfill revisions/access data, then advertise capability. Snapshot legacy plan content, but never mark unbound historical checks passed. Classify legacy sessions explicitly as shared or with a confirmed owner.
4. **Isolation:** use redacted database copies/fixtures and disable test-startup scan/execution/notification triggers. Validate read/demo mode. Real IM/email/ITSM/cloud writes are not part of this document’s verification.
5. **Rollout:** enable shell/Chat/Cases/Plans/Reports by user/deployment flags; observe errors, stream interruption, duplicate execution, denials and export failures.
6. **Rollback:** retain the old frontend build/image and disable new UI flags. Keep schema additions backward-compatible. If new revision-bound approvals exist, do not roll back to unguarded writes: retain backend protection and fall back to a read-only UI.

The existing ServiceNow/Jira bridge is best-effort lifecycle mirroring, not proof of reliable bidirectional approval. IM, webhook and ITSM credentials stay server-side. Reliable external approval requires separate signature/replay protection, identity mapping, idempotency and conflict acceptance. Browsers never connect directly with connector secrets.

UI delivery may proceed before customer writes are enabled. Write release requires identity, revision and verification gates. Where graph identity/facts do not meet the prior review requirements, show explicit degradation rather than zero impact and automatic approval.
"""),
("plan", "handoff", "交接与后续执行顺序", "Handoff and execution sequence", """
后续从 **P0 → P1** 开始：先确认最新代码/契约差异，再落地蓝白外壳和导航。随后先接只读 Cases/Resources 与已有 Chat 基础流，按 P2/P3 完成上下文和状态契约，再开放 P4 决策操作，最后完成 P5 双语报告交付。P2/P3 可独立分支推进，写操作必须等待共同依赖。

本次文件：

- `ui-refinement.html`：蓝白版可点击范本；所有对话/审批/发布仍是本地演示。
- `implementation-review.html`：中英文切换的综合审阅报告，含 API 搜索目录。
- `DESIGN.md`、`API_CONTRACT.md`、`IMPLEMENTATION_PLAN.md`：双语可版本管理文档。
- `api/existing-openapi.json`：原始服务快照。
- `api/target-openapi.json`：整体目标合同；`proposed-delta.openapi.json` 仅包含 40 个拟变更操作。
- `api/endpoint-catalog.json`、`change-register.json`、`state-mapping.json`、`design-tokens.json`：机器可读对接依据。

验证分界：本次检查范本交互、双语/响应式布局、OpenAPI 内部引用和契约样例。**没有对尚未实现的接口声称集成测试通过。** 真实产品运行代码、业务数据库和云环境不在本轮修改范围内。

协议依据：OpenAPI 3.1.0 官方规范；MDN 的 SSE 帧与 If-Match/412 说明。本文对 POST SSE 的实现以现有 fetch-stream 源码为准，不误用只适合 GET 的浏览器 EventSource 发送带附件消息。
""", """
Start implementation with **P0 → P1**: reconcile the latest code/contract, then implement the blue/white shell and navigation. Connect read-only Cases/Resources and existing Chat streaming, finish P2/P3 context/state contracts, open P4 decisions, then deliver P5 bilingual reporting. P2/P3 may branch independently; writes wait for shared prerequisites.

Deliverables:

- ui-refinement.html: clickable blue/white prototype; Chat, approval and publication remain local demos.
- implementation-review.html: language-switchable integrated report with a searchable API catalog.
- DESIGN.md, API_CONTRACT.md, IMPLEMENTATION_PLAN.md: bilingual version-controlled documents.
- api/existing-openapi.json: unchanged live snapshot.
- api/target-openapi.json: full target contract; proposed-delta.openapi.json contains the 40 changed operations only.
- endpoint-catalog.json, change-register.json, state-mapping.json and design-tokens.json: machine-readable implementation inputs.

Verification boundary: prototype interactions, bilingual/responsive rendering, OpenAPI internal references and contract examples. **Unimplemented APIs are not claimed to have passed integration tests.** No production runtime code, business database or cloud environment is changed in this delivery.

Protocol references: OpenAPI 3.1.0 and MDN’s SSE framing and If-Match/412 documentation. POST SSE implementation follows the existing fetch-stream source; browser EventSource is not used to send multipart POST messages.
"""),
]
